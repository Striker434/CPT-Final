//ICS3U-01
//Written by Adi Ganguli and Subhaan Ali

//Variable that Draws Screen
let screen = "intro";

//Variables Used for Tracking Screen
let frameX = 0;
let frameY = 0;
let curXY = [frameX, frameY];
let tarXY = [0, 0];
let exemplar = true, start = false;

//Variables for larger R.O.B.
let robX = 100;
let robY = -25;
let rise = 0;
let robXP = 100;
let robYP = -25;
let riseP = 0;
let t = -205;
let robAniTimer = 0;
let robLeft = false, robRight = false, robUp = false, robDown = false;
let robLight = 0, robLight2 = 0;

//Variables for Smaller R.O.B.
let y = 250;
let x = -40;

//Claw Machine Variables
let machineX = 0;
let machineY = 0;
let clawX = 0;
let clawY = 0;
let capture = false;
let bearX = 0;
let bearY = 0;
let down = false;
let extend = 0;
let count = 0;

//Text Variables
let text1 = [
    "Hey! Click the \"j\" and \"k\"key to change the colour of my \nlights! Notice the difference of pressing J and releasing K", 
  "This is done by using a value to hold the colour. If I press\n\"j\", then the Rob Head on the top turns on its light. This\nis different on the bottom Rob Head, as you need to\nrelease\"k\" to turn on it's light!",
  "The code looks like this. If the key is \"j\" or \"k\", it changes\nthe colour of the light on my head!"
    ];
let text2 = [
              "Hey! This claw machine uses keyCode and KeyIsPressed.\nUse the Arrow Keys to move the Claw and Enter to extend it! \nAnd after you catch a bear, use the Backspace key to drop it!",
              "The claw machine uses the keyCode and KeyIsDown\nvariables. KeyCode contains the keys needed and\nKeyIsDown checks when the key is held down.",
              "This is how it is coded. It uses if statements to move the\nclaws coordinates, and \"enter\" to extend the claw!"
];
let text3 = [
  "Some examples of Keyboard Interaction can be\nseen with keyboard shortcuts.",
  "Games also use Keyboard\nInteraction. Does this remind\nyou of anything? "
];
let text4 = [
  "Hey! I am made of all types of Keyboard Functions!\nTry controlling me with the arrow keys!", "You really like pushing my buttons, huh?"];
let jokeTimer = 0;
let jokeLine = 0;
let pressed = false;

//Loading all images
let img,img2,img3,img4,img5,img6

function preload(){
  img = loadImage("listofshortcuts.png");
  img2 = loadImage("flappybird.png");
  img3 = loadImage("Dino_idle.webp");
  img4 = loadImage("keyPressedandReleasedCode.png");
  img5 = loadImage("ENTERCODE.png");
  img6 = loadImage("clawCODE.png");
}

function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(250, 245, 157);
  
  //Determining Screen State
  if(curXY[0] == tarXY[0] && curXY[1] == tarXY[1] && exemplar && start){
    if(curXY[0] == 0 && curXY[1] == 0){
      screen = 'title';
    }
    if(curXY[0] == 600 && curXY[1] == 0){
      screen = 'keyLesson1';
    }
    if(curXY[0] == -600 && curXY[1] == 0){
      screen = 'keyLesson2';
    }
    if(curXY[0] == 0 && curXY[1] == -600){
      screen = 'keyLesson3'
    }
    if(curXY[0] == 0 && curXY[1] == 600){
      screen = 'keyLesson4';
    }
  }
  //Intro Screen
  if(screen == "intro"){
    //Drawing Intro Screen
    noStroke();
    fill(255);
    textSize(35)
    text("Keyboard Interaction with\n\t\t\t\t\t\t\t\tR.O.B", 97,37);
    stroke(0);
    strokeWeight(1);
    fill(0);
    textSize(35)
    text("Keyboard Interaction with\n\t\t\t\t\t\t\t\tR.O.B", 100,40);
    drawRobP(robX, robY + 35, rise);
    
    //Start Button on R.O.B's Chest
    fill(50);
    if(mouseX > 200 && mouseY > 290 && mouseX < 400 && mouseY < 340){
      fill(25);
    }
    strokeWeight(3);
    rect(200, 290, 200, 50, 5);
    stroke(255, 0, 0);
    //fill(255, 0, 0);
    if(mouseX > 200 && mouseY > 290 && mouseX < 400 && mouseY < 340){
      stroke(225, 0, 0);
      //fill(225, 0, 0);
    }
    //Letters for Start Button
    //textSize(40);
    //text("S T A R T", 210, 330)
    //S
    
    line(210, 295, 235, 295);
    line(210, 300, 210, 310);
    line(210, 315, 235, 315);
    line(235, 320, 235, 330);
    line(210, 335, 235, 335);
    //T
    line(245, 295, 275, 295);   
    line(260, 300, 260, 315);
    line(260, 320, 260, 335);
    //A
    line(285, 295, 310, 295);
    line(285, 300, 285, 315);
    line(310, 300, 310, 315);
    line(290, 317, 305, 317);
    line(285, 320, 285, 335);
    line(310, 320, 310, 335);
    //R
    line(320, 295, 345, 295);
    line(320, 300, 320, 315);
    line(345, 300, 345, 315);
    line(325, 315, 340, 315);
    line(320, 320, 320, 335);
    line(340, 320, 345, 335);
    //T
    line(355, 295, 385, 295);   
    line(370, 300, 370, 315);
    line(370, 320, 370, 335);
    fill(0);
  }
  
  //Title Screen
  if(screen == "title"){
  //Drawing the Title Screen
    //Setting Up Frames
    curXY = [frameX, frameY];
    //Title
    stroke(0);
    strokeWeight(1);
    noFill();
    rect(frameX, frameY, 600, 600);
    //Lesson to Left
    rect(frameX - 600, frameY, 600, 600);
    //Lesson to Right
    rect(frameX + 600, frameY, 600, 600);
    stroke(0);
    strokeWeight(1);
    noFill();
    //Lesson Above
    rect(frameX, frameY - 600, 600, 600);
    //Lesson Below
    rect(frameX, frameY + 600, 600, 600);
    
    //Drawing R.O.B.
    drawRob(robX, robY, rise); 
    
    //Code that shows direction for which lesson the user can access
    textSize(15);
    fill(0);
    strokeWeight(0);
    if(!(robLeft || robRight || robDown || robUp)){
      text("← KeyPressed and KeyReleased", 10,200);
      text("KeyCode and KeyIsDown →", 375,200);
      text("What is Keyboard Interaction\n\t\t\t\t\t\t\t\t\t\t\t↓", 210,550);
      text("\t\t\t\t\t\t\t\t\t\t\t↑\n\t\t\t\t\t\tPlay with Rob", 210,30);
    }
    
    //Screens Sliding
    if(curXY[0] != tarXY[0] && robAniTimer >= 8){
      if(curXY[0] > tarXY[0]){
        frameX -= 5;
      }
      if(curXY[0] < tarXY[0]){
        frameX += 5;
      }
    }
    if(curXY[1] != tarXY[1] && robAniTimer >= 8){
      if(curXY[1] > tarXY[1]){
        frameY -= 5;
      }
      if(curXY[1] < tarXY[1]){
        frameY += 5;
      }
    }
  
    //Animation for R.O.B. to pull screen   
    //Bringing in Left Screen
    if(keyIsDown(LEFT_ARROW) && !(robRight || robUp || robDown)){
      tarXY = [600, 0];
      robLeft = true;      
    }
    if(robLeft == true){
      robAniTimer++;
      if(robAniTimer >= 0 && robAniTimer <= 9){
        robX = 0;
        robY = -25;
      }
      if(robAniTimer >=10){
        robX += 5;
      }
    }
    
    //Bringing in Right Screen
    if(keyIsDown(RIGHT_ARROW) && !(robLeft || robUp || robDown)){
      tarXY = [-600, 0];
      robRight = true;
    }
    if(robRight == true){
      robAniTimer++;
      if(robAniTimer >= 0 && robAniTimer <= 9){
        robX = 210;
        robY = -25;
      }
      if(robAniTimer >= 10){
        robX -= 5;
      } 
    }
     
    //Bringing in Bottom Screen
    if(keyIsDown(DOWN_ARROW) && !(robLeft || robUp || robRight)){
      tarXY = [0, -600];
      robDown = true;
    }
    if(robDown == true){
      robAniTimer++;
      if(robAniTimer >= 0 && robAniTimer <= 9){
        rise = 50;
        robX = 100;
        robY = 135;
      }
      if(robAniTimer >= 10){
        robY -= 5;
      }
    }
    
    //Bringing in Top Screen
    if(keyIsDown(UP_ARROW) && !(robLeft || robDown || robRight)){
      tarXY = [0, 600];
      robUp = true;
      
    }
    if(robUp == true){
      robAniTimer++;
      if(robAniTimer >= 0 && robAniTimer <= 9){
        rise = -55;
        robX = 100;
        robY = -60;
      }
      if(robAniTimer >= 10){
        robY += 5;
      } 
    }
       
  }
  
  //Key Lesson 1
  if(screen == "keyLesson1" || robLeft){
    textSize(12);
    strokeWeight(1);
    stroke(0);
    drawRobText(x + frameX - 600, y + frameY);
    
    fill(0)
    text(text1[0], 230 + frameX - 600, 520 + frameY);
    textSize(25);
    text("KeyPressed and KeyReleased", 130 + frameX - 600, 40 + frameY);
    fill(255);
    
    if(mouseX >= 35 && mouseX <= 155 && mouseY >= 60 && mouseY <= 110 && screen == "keyLesson1"){
      fill(169);
    }
    rect(35 + frameX - 600, 60 + frameY, 120, 50);
    fill(0);
    textSize(17);
    text("Back", 75 + frameX - 600, 90 + frameY);
    fill(255);
    stroke(1);
    if(mouseX >= 35 && mouseX <= 155 && mouseY >= 120 && mouseY <= 170){
      fill(169);
    }
    rect(35 + frameX - 600, 120 + frameY, 120, 50);
    fill(0);
    textSize(17)
    text("How It Works", 45 + frameX - 600, 150 + frameY);
    fill(50);
    
    drawRobHead(100 + frameX - 600, 75 + frameY);
    drawRobHead2(100 + frameX - 600, 225 + frameY)  
  }
  
  //Key Lesson 2
  if(screen == "keyLesson2" || robRight){
    textSize(11);
    strokeWeight(1);
    stroke(0);
    drawRobText(x + frameX  + 600, y + frameY);
    fill(0)
    text(text2[0], 230 + frameX + 600, 515 + frameY);
    textSize(25);
    text("KeyCode and KeyIsDown", 150 + frameX + 600, 40 + frameY);
    
    //Draws button
    fill(255)
    if(mouseX >= 440 && mouseX <= 560 && mouseY >= 65 && mouseY <= 125 && screen == "keyLesson2"){
      fill(169);
    }
    rect(440 + frameX + 600, 70 + frameY, 120, 50);
    fill(0);
    textSize(17);
    text("Back", 480 + frameX + 600, 100 + frameY);
    
    fill(255)
    if(mouseX >= 440 && mouseX <= 560 && mouseY >= 140 && mouseY <= 190 && screen == "keyLesson2"){
      fill(169);
    }
    rect(440 + frameX + 600, 140 + frameY, 120, 50);
    
    fill(0);
    textSize(17);
    text("How it Works", 450 + frameX + 600, 170 + frameY);
    
    //Draws Captured Bear
    if(capture == true){
      drawCBear(clawX + 30 + frameX + 600, clawY + 25 + extend + frameY);
    }
    //Draws Claw Machine
    drawArcadeMachine(machineX + frameX + 600, machineY + frameY, clawX + frameX + 600, clawY + frameY); 
    
    //Draw Bears in the Claw Machine
    drawBears(machineX + 25 + frameX + 600, machineY + 65 + frameY);
    drawBears(machineX + 55 + frameX + 600, machineY + 68 + frameY);
    drawBears(machineX + 40 + frameX + 600, machineY + 75 + frameY);
    drawBears(machineX + 15 + frameX + 600, machineY + 80 + frameY);
    drawBears(machineX + 35 + frameX + 600, machineY + 90 + frameY);
    drawBears(machineX + 55 + frameX + 600, machineY + 95 + frameY);
    drawBears(machineX - 25 + frameX + 600, machineY + 75 + frameY);
    drawBears(machineX - 45 + frameX + 600, machineY + 80 + frameY);
    drawBears(machineX - 10 + frameX + 600, machineY + 85 + frameY);
    drawBears(machineX + 105 + frameX + 600, machineY + 68 + frameY);
    drawBears(machineX + 85 + frameX + 600, machineY + 73 + frameY);
    drawBears(machineX + 130 + frameX + 600, machineY + 70 + frameY);
    drawBears(machineX + 100 + frameX + 600, machineY + 80 + frameY);
    drawBears(machineX + 87 + frameX + 600, machineY + 89 + frameY); 
  }
  
  //Key Lesson 3
  if(screen == "keyLesson3" || robDown){
    textSize(13);
    drawSRobHead(x-35 + frameX, y-270 + frameY + 600);
    drawRobText(x + frameX,y + frameY + 600);
    fill(0)
    text(text3[0],230 + frameX,520 + frameY + 600);
    textSize(25);
    text("Examples of Keyboard Interaction", 110 + frameX,40 + frameY + 600);
    
    //Button
    fill(255);
    if(mouseX >= 440 && mouseX <= 560 && mouseY >= 65 && mouseY <= 125 && screen == "keyLesson3"){
      fill(169);
    }
    rect(440 + frameX,70 + frameY + 600,120,50);
    fill(0);
    textSize(17);
    text("Back", 480 + frameX,100 + frameY + 600);
    
    //Images
    image(img,220 + frameX,250 + frameY + 600,300,220)
    image(img2,280 + frameX,140 + frameY + 600,80,60)
    image(img3,170 + frameX,120 + frameY + 600,90,90)
    
    //Speech Bubble
    fill(255);
    triangle(75 + frameX,220 + frameY + 600,65 + frameX,200 + frameY + 600,85 + frameX,200 + frameY + 600);
    ellipse(75 + frameX,170 + frameY + 600,150,75)
    fill(0);
    textSize(10)
    text(text3[1],15 + frameX,157.5 + frameY + 600)
}
  
  //Key Lesson 4
  if(screen == "keyLesson4" || robUp){
    drawRobP(robXP + frameX, robYP - 15 + frameY - 600, riseP); 
    if(keyIsDown(UP_ARROW) && riseP > -55){
      riseP -= 1;
    }
    if(keyIsDown(DOWN_ARROW) && riseP < 50){
      riseP += 1;
    }
    
    textSize(13);
    drawRobText(x + frameX,y + frameY - 600);
    fill(0)
    text(text4[jokeLine],230 + frameX,520 + frameY - 600);
    textSize(25);
    text("Play with Rob", 220 + frameX,35 + frameY - 600);
    
    //How to use R.O.B. Button
    fill(255)
    if(mouseX >= 35 && mouseX <= 155 && mouseY >= 45 && mouseY <= 105 && screen == "keyLesson4"){
      fill(169)
    }
    rect(35 + frameX,50 + frameY - 600,120,50)
    fill(0)
    textSize(12)
    text("How to Use", 65 + frameX,78 + frameY - 600)
    fill(255);
    if(mouseX >= 440 && mouseX <= 560 && mouseY >= 45 && mouseY <= 105 && screen == "keyLesson4"){
      fill(169);
    }
    rect(440 + frameX,50 + frameY - 600,120,50);
    fill(0);
    textSize(17);
    text("Back", 480 + frameX,80 + frameY - 600);
    
    //Changing text when you interact with R.O.B. too much
    if(screen == "keyLesson4"){
      if(keyIsDown(LEFT_ARROW)){
        pressed = true;
      }
      if(keyIsDown(RIGHT_ARROW)){
        pressed = true;
      }
      if(keyIsDown(DOWN_ARROW)){
        pressed = true;
      }
      if(keyIsDown(UP_ARROW)){
        pressed = true;
      }
    }
    if(pressed){
      jokeTimer+=0.1;
    }
    if(jokeTimer >= 100){
      jokeLine = 1;
    }
  }
  
  //How R.O.B. Works Screen
  if(screen == "howRobWorks"){
    background(24, 245, 157);
    drawRobP(robXP,robYP,riseP);
    drawRobText(x,y);
    fill(0);
    textSize(13);
    text("Use the left and right arrow keys to move Rob's\narms, and the up and down keys to move his torso!",230,520);
    fill(255);
    if(mouseX >= 35 && mouseX <= 155 && mouseY >= 45 && mouseY <= 105 && screen == "howRobWorks"){
      fill(169);
    }
    rect(35,50,120,50);
    fill(0);
    textSize(17);
    text("Back", 75,80);
  }
  
  //How It Works Screens
  if(screen == "works1"){
    background(24, 245, 157);
    //Outer Text Box
    fill(255)
    stroke(5)
    rect(10,10,580,90)
    
    //Circle Under R.O.B.
    fill(166, 245, 140)
    ellipse(110,55,150,75)
    
    //Text
    fill(255);
    stroke(1);
    rect(225,20,310,70);
    drawRobText(x,y-470);
    drawRobText(x,y);
    fill(0)
    textSize(11);
    text(text1[1], 230,40)
    text(text1[2],230,520);
    //Button
    fill(255)
    if(mouseX >= 440 && mouseX <= 560 && mouseY >= 140 && mouseY <= 190 && screen == "works1"){
      fill(169);
    }
    rect(440,140,120,50);
    fill(0);
    textSize(17);
    text("Back", 480,170);
    image(img4,15,165,400,250);
    textSize(12);
  }
  
  if(screen == "works2"){
    background(24, 245, 157);
    //Outer Text Box
    fill(255)
    stroke(5)
    rect(10,10,580,90)
    
    //Circle under R.O.B.
    fill(166, 245, 140)
    ellipse(110,55,150,75);
    
    //Text
    fill(255);
    stroke(1);
    rect(225,20,310,70);
    drawRobText(x,y-470);
    drawRobText(x,y);
    fill(0)
    textSize(12);
    text(text2[1], 230,40)
    text(text2[2],230,520);
    
    //Button
    fill(255)
    if(mouseX >= 440 && mouseX <= 560 && mouseY >= 140 && mouseY <= 190 && screen == "works2"){
      fill(169);
    }
    rect(440,140,120,50);
    fill(0);
    textSize(17);
    text("Back", 480,170);
    image(img5,5,130,430,60);
    image(img6,40,220,450,230);
    textSize(12);
  }
   
}
function drawArcadeMachine(x, y){
  stroke(1);
  //Glass case
  line(x + 120, y + 320, x + 120, y + 155);
  line(x + 365, y + 300, x + 365, y + 150);
  line(x + 225, y + 280, x + 225, y + 140);
  
  //Claw
  fill(210);
  rect(x + 245 + clawX, y + 155, 10, 60 + extend);
  strokeWeight(2)
  if(capture == false){
    line(x + 245 + clawX, y + 215 + extend, x + 238 + clawX, y + 225 + extend);
    line(x + 255 + clawX, y + 215 + extend, x + 260 + clawX, y + 225 + extend);
    line(x + 238 + clawX, y + 225 + extend, x + 245 + clawX, y + 230 + extend);
    line(x + 260 + clawX, y + 225 + extend, x + 255 + clawX, y + 230 + extend);
  }
 
  line(x + 250 + clawX, y + 215 + extend, x + 250 + clawX, y + 230 + extend);
  strokeWeight(1)
  
  //Bottom
  fill(250, 115, 105);
  beginShape();
  vertex(x + 270, y + 420);
  vertex(x + 120, y + 400);
  vertex(x + 120, y + 320);
  vertex(x + 270, y + 340);
  endShape();
  
  beginShape();
  vertex(x + 270, y + 340);
  vertex(x + 365, y + 300);
  vertex(x + 365, y + 390);
  vertex(x + 270, y + 420);
  endShape();
  
  beginShape();
  vertex(x + 270, y + 340);
  vertex(x + 120, y + 320);
  vertex(x + 225, y + 280);
  vertex(x + 365, y + 300);
  endShape();
  
  //Top
  beginShape();
  vertex(x + 270, y + 200);
  vertex(x + 120, y + 180);
  vertex(x + 120, y + 100);
  vertex(x + 270, y + 120);
  endShape();
  
  beginShape();
  vertex(x + 270, y + 120);
  vertex(x + 365, y + 80);
  vertex(x + 365, y + 170);
  vertex(x + 270, y + 200);
  endShape();
  
  beginShape();
  vertex(x + 270, y + 120);
  vertex(x + 120, y + 100);
  vertex(x + 225, y + 60);
  vertex(x + 365, y + 80);
  endShape();
  line(x + 270, y + 120, x + 270, y + 419);
  
  //Bin
  fill(140, 66, 60);

  beginShape();
  vertex(x + 300, y + 350);
  vertex(x + 300, y + 380);
  vertex(x + 280, y + 390);
  vertex(x + 280, y + 360);
  endShape();  
  
  line(x + 280, y + 360, x + 300, y + 350);
  line(x + 293, y + 353, x + 293, y + 375);
  line(x + 293, y + 375, x + 300, y + 380);
  line(x + 293, y + 375, x + 300, y + 380);
  line(x + 293, y + 375, x + 280, y + 380);
  
  //Joystick
  fill(222, 164, 160)
  
  
  beginShape();
  vertex(x + 330, y + 335);
  vertex(x + 350, y + 325);
  vertex(x + 350, y + 340);
  vertex(x + 330, y + 350);
  endShape();
  
  beginShape();
  vertex(x + 330, y + 350);
  vertex(x + 315, y + 350);
  vertex(x + 315, y + 335);
  vertex(x + 330, y + 335);
  endShape();
  
  beginShape();
  vertex(x + 315, y + 335);
  vertex(x + 335, y + 325);
  vertex(x + 350, y + 325);
  vertex(x + 330, y + 335);
  endShape();
  
  line(x + 330, y + 350, x + 330, y + 335 );
  strokeWeight(1.5);
  line(x + 333, y + 328, x + 348, y + 315);
  fill(255,0,0);
  ellipse(x + 350,y + 310, 15,15);
  
  //Claw Movement
  if(keyIsDown(ENTER) && extend == 0 && capture == false){
     down = true;
  }
  if(down && extend < 65){
    extend++;
  }
  if(extend == 65 && count < 60){
    count++;
    down = false;
    capture = true;
  }
  if(count == 60 && extend > 0){
    extend--;
  }
  //claw moving left or right
  if(keyIsDown(LEFT_ARROW) && !down && extend == 0) {
    //claw moves left
    clawX--;
    //stops the claw at a certain point
    if(clawX <= -85 && keyIsDown(LEFT_ARROW)){
      clawX++;
    }
  }
  if(keyIsDown(RIGHT_ARROW) && !down && extend == 0) {
    //claw moves right
    clawX++;
    //stops the claw at a certain point
    if(clawX >= 70){
      clawX--;
    } 
  } 
}
function drawBears(x, y){
  //Face Details
    //Ears
  stroke(0);
  strokeWeight(1);
  fill(244, 166, 104);
  arc(190 + x, 200 + y, 8, 8, HALF_PI, TWO_PI);
  arc(210 + x, 200 + y, 8, 8, PI, HALF_PI);
  
  noStroke(0);
  strokeWeight(1);
  fill(247, 201, 166);
  arc(190 + x, 200 + y, 4, 4, HALF_PI, TWO_PI);
  arc(210 + x, 200 + y, 4, 4, PI, HALF_PI);
  
    //Face, Body, and Snout
  stroke(0);
  strokeWeight(1);
  fill(244, 166, 104);
  ellipse(200 + x, 225 + y, 20, 25);
  ellipse(200 + x, 207 + y, 25, 18);
  
  stroke(0);
  strokeWeight(1);
  fill(247, 201, 166);
  ellipse(200 + x, 210 + y, 15, 10);
  
  stroke(0);
  strokeWeight(1);
  fill(0);
  ellipse(200 + x, 207 + y, 4, 3);
  noFill();
  arc(198 + x, 207 + y, 5, 10, 0, HALF_PI);
  arc(202 + x, 207 + y, 5, 10, HALF_PI, PI);
  
    //Eyes
  stroke(0);
  strokeWeight(1);
  fill(0);
  ellipse(195 + x, 205 + y, 3, 3);
  ellipse(205 + x, 205 + y, 3, 3);
  noStroke();
  fill(255);
  ellipse(196 + x, 204 + y, 2, 2);
  ellipse(206 + x, 204 + y, 2, 2);
  
  //Appendages
  stroke(0);
  strokeWeight(1);
  fill(244, 166, 104);
  ellipse(192 + x, 235 + y, 13, 10);
  ellipse(208 + x, 235 + y, 13, 10);
  ellipse(190 + x, 222 + y, 8, 15);
  ellipse(210 + x, 222 + y, 8, 15);
  
  noStroke();
  fill(247, 201, 166);
  ellipse(192 + x, 235 + y, 8, 5);
  ellipse(208 + x, 235 + y, 8, 5);
}
function drawCBear(x, y){
  //Face Details
    //Ears
  stroke(0);
  strokeWeight(1);
  fill(244, 166, 104);
  arc(200 + x, 190 + y, 8, 8, HALF_PI, TWO_PI);
  arc(200 + x, 210 + y, 8, 8, 0, HALF_PI + PI);
  
  noStroke(0);
  strokeWeight(1);
  fill(247, 201, 166);
  arc(200 + x, 190 + y, 4, 4, HALF_PI, TWO_PI);
  arc(200 + x, 210 + y, 4, 4, 0, HALF_PI + PI);
  
    //Face, Body, and Snout
  stroke(0);
  strokeWeight(1);
  fill(244, 166, 104);
  ellipse(225 + x, 200 + y, 25, 20);
  ellipse(207 + x, 200 + y, 18, 25);
  
  stroke(0);
  strokeWeight(1);
  fill(247, 201, 166);
  ellipse(210 + x, 200 + y, 10, 15);
  
  stroke(0);
  strokeWeight(1);
  fill(0);
  ellipse(207 + x, 200 + y, 3, 4);
  noFill();
  arc(207 + x, 198 + y, 10, 5, 0, HALF_PI);
  arc(207 + x, 202 + y, 10, 5, HALF_PI + PI, 0);
  
    //Eyes
  stroke(0);
  strokeWeight(1);
  fill(0);
  ellipse(205 + x, 195 + y, 3, 3);
  ellipse(205 + x, 205 + y, 3, 3);
  noStroke();
  fill(255);
  ellipse(204 + x, 196 + y, 2, 2);
  ellipse(204 + x, 206 + y, 2, 2);
  
  //Appendages
  stroke(0);
  strokeWeight(1);
  fill(244, 166, 104);
  ellipse(235 + x, 192 + y, 10, 13);
  ellipse(235 + x, 208 + y, 10, 13);
  ellipse(222 + x, 190 + y, 15, 8);
  ellipse(222 + x, 210 + y, 15, 8);
  
  noStroke();
  fill(247, 201, 166);
  ellipse(235 + x, 192 + y, 5, 8);
  ellipse(235 + x, 208 + y, 5, 8);
}
function drawRobText(x,y){
  //Outer text box
  fill(255)
  stroke(5)
  rect(50 + x, 230 + y,580,90)
  //Circle under R.O.B.
  fill(166, 245, 140)
  ellipse(150 + x, 275+ y,150,75)
  
  //R.O.B. light
  fill(random(100,255),0,0)
  ellipse(150 + x, 250 + y,15)
  
  //Side Ears
  stroke(0);
  strokeWeight(1);
  fill(225);
  rect(95 + x, 260 + y, 10, 30, 10);
  rect(195 + x, 260 + y, 10, 30, 10);
  
  //Outer head
  rect(100 + x, 250 + y, 100, 50, 10);
  
  //Outer black visor
  fill(60);
  rect(105 + x, 255 + y, 90, 40, 10);
  strokeWeight(2);
  fill(40); 
  rect(107.5 + x, 260 + y, 85, 28, 20);
  
  //Inner lines connecting eyes
  fill(0);
  stroke(0);
  strokeWeight(3);
  line(135 + x, 265 + y, 165 + x, 265 + y);
  line(135 + x, 273 + y, 165 + x, 273+ y);
  line(135 + x, 282.5 + y, 165 + x, 282.5 + y);
  
  //Eyes
  fill(0);
  stroke(0);
  strokeWeight(1);
  ellipse(125 + x, 274 + y, 25, 25);
  ellipse(175 + x, 274 + y, 25, 25);
  
  //Lighting for Eyes
  fill(255, 175);
  noStroke();
  ellipse(127.5+ x, 270 + y, 5, 5);
  ellipse(180 + x, 270 + y, 5, 5);
  
  //text
  fill(255);
  stroke(1);
  rect(265 + x,245 + y,310,60);
}
function drawSRobHead(x, y){
  //R.O.B. light
  fill(random(100,255),0,0)
  ellipse(150 + x, 250 + y,15)
  
  //Side Ears 
  stroke(0);
  strokeWeight(1);
  fill(225);
  rect(95 + x, 260 + y, 10, 30, 10);
  rect(195 + x, 260 + y, 10, 30, 10);
  
  //Outer head
  rect(100 + x, 250 + y, 100, 50, 10);
  
  //Outer black visor
  fill(60);
  rect(105 + x, 255 + y, 90, 40, 10);
  strokeWeight(2);
  fill(40); 
  rect(107.5 + x, 260 + y, 85, 28, 20);
  
  //Inner lines connecting eyes
  fill(0);
  stroke(0);
  strokeWeight(3);
  line(135 + x, 265 + y, 165 + x, 265 + y);
  line(135 + x, 273 + y, 165 + x, 273+ y);
  line(135 + x, 282.5 + y, 165 + x, 282.5 + y);
  
  //Eyes
  fill(0);
  stroke(0);
  strokeWeight(1);
  ellipse(125 + x, 274 + y, 25, 25);
  ellipse(175 + x, 274 + y, 25, 25);
  
  //Lighting for Eyes
  fill(255, 175);
  noStroke();
  ellipse(127.5+ x, 270 + y, 5, 5);
  ellipse(180 + x, 270 + y, 5, 5);
}
function drawRobP(x, y, h){
  //Face
  stroke(0);
  strokeWeight(1);
  fill(random(255, 0), 0, 0);
  ellipse(200 + x, 100 + y, 10, 15);
  
  fill(225);
  rect(195 + x, 98 + y, 10, 5);
  rect(95 + x, 120 + y, 10, 60, 10);
  rect(295 + x, 120 + y, 10, 60, 10);

  rect(100 + x, 100 + y, 200, 100, 10);
  
  fill(40);
  rect(107 + x, 107 + y, 186, 86, 10);
  
  strokeWeight(2);
  fill(30);
  rect(115 + x, 115 + y, 170, 70, 20);
  
  fill(0);
  stroke(0);
  strokeWeight(5);
  line(150 + x, 135 + y, 250 + x, 135 + y);
  line(150 + x, 150 + y, 250 + x, 150 + y);
  line(150 + x, 165 + y, 250 + x, 165 + y);
  
  //Eyes
  fill(0);
  stroke(0);
  strokeWeight(1);
  ellipse(150 + x, 150 + y, 60, 60);
  ellipse(250 + x, 150 + y, 60, 60);
  
  //Lighting for Eyes
  fill(255, 175);
  noStroke();
  ellipse(160 + x, 135 + y, 10, 10);
  ellipse(260 + x, 135 + y, 10, 10);
  
  //Eye Reflection
  for(var i = 0; i <= 5; i++){
    fill(125 - i * 25, 150);
    arc(150 + x, 150 + y, 60 - i * 5, 60 - i * 5, 70, 650);
    fill(0);
    arc(150 + x, 150 + y, 55 - i * 5, 55 - i * 5, 70, 650);
    fill(125 - i * 25, 150);
    arc(250 + x, 150 + y, 60 - i * 5, 60 - i * 5, 70, 650);
    fill(0);
    arc(250 + x, 150 + y, 55 - i * 5, 55 - i * 5, 70, 650);
  }
  
  //Neck
  stroke(0);
  strokeWeight(1);
  fill(205);
  rect(170 + x, 200 + y, 60, 5);
  rect(170 + x, 205 + y, 15, 15);
  rect(195 + x, 205 + y, 10, 15);
  rect(215 + x, 205 + y, 15, 15);
  rect(170 + x, 215 + y, 60, 5);
  fill(235);
  
  //Base
  stroke(0);
  strokeWeight(1);
  fill(210);
  beginShape();
  vertex(330 + x, 425 + y);
  vertex(330 + x, 455 + y);
  vertex(275 + x, 535 + y);
  vertex(125 + x, 535 + y);
  vertex(70 + x, 455 + y);
  vertex(70 + x, 425 + y);
  vertex(330 + x, 425 + y);
  endShape();
  
  stroke(0);
  strokeWeight(1);
  fill(240);
  beginShape();
  vertex(70 + x, 425 + y);
  vertex(125 + x, 505 + y);
  vertex(275 + x, 505 + y);
  vertex(330 + x, 425 + y);
  vertex(275 + x, 380 + y);
  vertex(125 + x, 380 + y);
  vertex(70 + x, 425 + y);
  endShape();
  
  fill(230);
  for(i = 0; i < 5; i++){
    ellipse(200 + x, 425 + y + i, 175, 75);
  }
  fill(235);
  ellipse(200 + x, 425 + y, 175, 75);
  fill(220);
  for(i = 0; i < 5; i++){
    ellipse(200 + x, 420 + y + i, 125, 50);
  }
  fill(235);
  ellipse(200 + x, 420 + y, 125, 50);  
  
  fill(230);
  for(i = 0; i < 5; i++){
    beginShape();
    vertex(250 + x, 455 + y + i);
    vertex(255 + x, 510 + y + i);
    vertex(220 + x, 510 + y + i);
    vertex(220 + x, 485 + y + i);
    vertex(180 + x, 485 + y + i);
    vertex(180 + x, 510 + y + i);
    vertex(145 + x, 510 + y + i);
    vertex(150 + x, 455 + y + i);
    endShape();
  }
  fill(235);
  beginShape();
  vertex(250 + x, 455 + y);
  vertex(255 + x, 510 + y);
  vertex(220 + x, 510 + y);
  vertex(220 + x, 485 + y);
  vertex(180 + x, 485 + y);
  vertex(180 + x, 510 + y);
  vertex(145 + x, 510 + y);
  vertex(150 + x, 455 + y);
  endShape();
  
  fill(220);
  stroke(0);
  rect(145 + x, 510 + y, 35, 30);
  rect(220 + x, 510 + y, 35, 30);
  
  noStroke();
  fill(100, 20)
  beginShape();
  vertex(320 + x, 425 + y);
  vertex(80 + x, 425 + y);
  vertex(125 + x, 380 + y);
  vertex(275 + x, 380 + y);
  vertex(320 + x, 425 + y);
  endShape();
  
  // Spine
  stroke(0);
  fill(225);
  rect(175 + x, 220 + y, 50, 200);
  fill(230);
  rect(185 + x, 220 + y, 30, 200);
  for(i = 0; i  < 200; i += 2){
    strokeWeight(0.5);
    line(180 + x, 220 + i + y, 185 + x, 220 + i + y);
    line(215 + x, 220 + i + y, 220 + x, 220 + i + y);
  }
  
  noFill();
  stroke(220);
  strokeWeight(3);
  for(i = 1; i < 40; i++){
    arc(200 + x, 375 + y + i, 60, 20, radians(350), radians(190));
  }
  
  stroke(0);
  strokeWeight(1);
  arc(200 + x, 375 + y, 60, 20, radians(350), radians(190));
  arc(200 + x, 415 + y, 60, 20, radians(360), radians(180));
  line(170 + x, 375 + y, 170 + x, 415 + y);
  line(230 + x, 375 + y, 230 + x, 415 + y);
  
  //Upper Body
    //Straight View
  if(keyIsDown(LEFT_ARROW) && keyIsDown(RIGHT_ARROW) || (!keyIsDown(LEFT_ARROW) && !keyIsDown(RIGHT_ARROW)) || screen == "intro"){
    stroke(0);
    strokeWeight(1)
    fill(235);
    ellipse(70 + x, 305 + y + h, 90, 60);
    ellipse(330 + x, 305 + y + h, 90, 60);
  
    noStroke();
    fill(40);
    rect(40 + x, 285 + y + h, 50, 40, 10);
    rect(310 + x, 285 + y + h, 50, 40, 10);

    stroke(0);
    strokeWeight(1);
    fill(235);
    rect(80 + x, 275 + y + h, 240, 40, 20, 20, 0, 0);
    fill(235);
    rect(80 + x, 315 + y + h, 240, 20, 0, 0, 10, 10);
    fill(205);
    rect(160 + x, 275 + y + h , 80, 30, 3, 3, 10, 10);
    noStroke();
    fill(0, 20);
    rect(95 + x, 275 + y + h, 210, 40 - (h / 3 + 20), 10);
  
    //Arms
      //Left Clamp
    stroke(0);
    strokeWeight(1);
    fill(40);
    for(i = 0; i < 20; i++){
      rect(20 + x, 377 + y + h + i, 130, 20, 5, 10, 10, 10);
    }
    fill(60);
    rect(20 + x, 377 + y + h, 130, 20, 5, 10, 10, 10);
  
    fill(155);
    beginShape();
    vertex(85 + x, 395 + y + h);
    vertex(140 + x, 375 + y + h);
    vertex(155 + x, 375 + y + h);
    vertex(145 + x, 405 + y + h);
    vertex(80 + x, 400 + y + h);
    vertex(85 + x, 395 + y + h);
    endShape();
  
    fill(145);
    beginShape();
    vertex(80 + x, 400 + y + h);
    vertex(145 + x, 405 + y + h);
    vertex(145 + x, 425 + y + h);
    vertex(80 + x, 420 + y + h);
    vertex(80 + x, 400 + y + h);
    endShape();
  
    fill(0);
    beginShape();
    vertex(145 + x, 425 + y + h);
    vertex(145 + x, 405 + y + h);
    vertex(155 + x, 375 + y + h);
    vertex(155 + x, 395 + y + h);
    vertex(145 + x, 425 + y + h);
    endShape();
  
      //Left Arm
    fill(75);
    for(i = 0; i < 5; i++){
      arc(80 + x - i, 385 + y + h + i, 20, 20, 0, PI);
      beginShape();
      vertex(70 + x - i, 385 + y + h + i);
      vertex(75 + x - i, 365 + y + h + i);  
      vertex(75 + x - i, 365 + y + h + i);
      vertex(50 + x - i, 320 + y + h + i);
      vertex(70 + x - i, 320 + y + h + i);
      vertex(95 + x - i, 365 + y + h + i);
      vertex(90 + x - i, 385 + y + h + i);
      endShape();
    
      beginShape();
      vertex(59 + x - i , 335 + y + h + i);
      vertex(28 + x - i, 320 + y + h + i);
      vertex(40 + x - i, 287 + y + h + i);
      vertex(77 + x - i, 290 + y + h + i);
      vertex(74 + x - i, 325 + y + h + i);
      endShape();
    }
    fill(155);
    stroke(1);
    strokeWeight(1);
    arc(80 + x, 385 + y + h, 20, 20, 0, PI);
    beginShape();
    vertex(70 + x, 385 + y + h);
    vertex(75 + x, 365 + y + h);  
    vertex(75 + x, 365 + y + h);
    vertex(50 + x, 320 + y + h);
    vertex(70 + x, 320 + y + h);
    vertex(95 + x, 365 + y + h);
    vertex(90 + x, 385 + y + h);
    endShape();
    
    beginShape();
    vertex(59 + x, 335 + y + h);
    vertex(28 + x, 320 + y + h);
    vertex(40 + x, 287 + y + h );
    vertex(77 + x, 290 + y + h);
    vertex(74 + x, 325 + y + h);
    endShape();

      //Right Clamp
    fill(40);
    for(i = 0; i < 20; i++){
      rect(250 + x, 377 + y + h + i, 130, 20, 10, 5, 10, 10);
    }
    fill(60);
    rect(250 + x, 377 + y + h, 130, 20, 10, 5, 10, 10);
      
    fill(40);
    for(i = 0; i < 5; i++){
      ellipse(350 + x, 385 + y + h + i, 10, 5);
      ellipse(320 + x, 385 + y + h + i, 10, 5);
    }
    fill(60);
    ellipse(350 + x, 385 + y + h, 10, 5);
    ellipse(320 + x, 385 + y + h, 10, 5);
  
    fill(155);
    beginShape();
    vertex(315 + x, 395 + y + h);
    vertex(255 + x, 375 + y + h);
    vertex(245 + x, 375 + y + h);
    vertex(255 + x, 405 + y + h);
    vertex(320 + x, 400 + y + h);
    vertex(315 + x, 395 + y + h);
    endShape();
  
    fill(145);
    beginShape();
    vertex(320 + x, 400 + y + h);
    vertex(255 + x, 405 + y + h);
    vertex(255 + x, 425 + y + h);
    vertex(320 + x, 420 + y + h);
    vertex(320 + x, 400 + y + h);
    endShape();
  
    fill(0);
    beginShape();
    vertex(255 + x, 425 + y + h);
    vertex(245 + x, 395 + y + h);
    vertex(245 + x, 375 + y + h);
    vertex(255 + x, 405 + y + h);
    vertex(255 + x, 425 + y + h);
    endShape();
  
  
      //Right Arm
    fill(75);
    for(i = 0; i < 5; i++){
      arc(320 + x + i, 385 + y + h + i, 20, 20, 0, PI);
      beginShape();
      vertex(330 + x + i, 385 + y + h + i);
      vertex(325 + x + i, 365 + y + h + i);  
      vertex(325 + x + i, 365 + y + h + i);
      vertex(350 + x + i, 320 + y + h + i);
      vertex(330 + x + i, 320 + y + h + i);
      vertex(305 + x + i, 365 + y + h + i);
      vertex(310 + x + i, 385 + y + h + i);
      endShape();
    
      beginShape();
      vertex(341 + x + i, 335 + y + h + i);
      vertex(372 + x + i, 320 + y + h + i);
      vertex(360 + x + i, 287 + y + h + i);
      vertex(323 + x + i, 290 + y + h + i);
      vertex(326 + x + i, 325 + y + h + i);
      endShape();
    }
    fill(155);
    stroke(1);
    strokeWeight(1);
    arc(320 + x, 385 + y + h, 20, 20, 0, PI);
    beginShape();
    vertex(330 + x, 385 + y + h);
    vertex(325 + x, 365 + y + h);  
    vertex(325 + x, 365 + y + h);
    vertex(350 + x, 320 + y + h);
    vertex(330 + x, 320 + y + h);
    vertex(305 + x, 365 + y + h);
    vertex(310 + x, 385 + y + h);
    endShape();
  
    beginShape();
    vertex(341 + x, 335 + y + h + i);
    vertex(372 + x, 320 + y + h + i);
    vertex(360 + x, 287 + y + h + i);
    vertex(323 + x, 290 + y + h + i);
    vertex(326 + x, 325 + y + h + i);
    endShape();
  
    //Extra Design on Arm
    fill(60);
    ellipse(50 + x, 385 + y + h, 10, 5);
    ellipse(80 + x, 385 + y + h, 10, 5);
    ellipse(350 + x, 385 + y + h, 10, 5);
    ellipse(320 + x, 385 + y + h, 10, 5);
  }
  
    //Right View
  if(keyIsDown(RIGHT_ARROW) && !keyIsDown(LEFT_ARROW) && screen != "intro"){
    //Right Arm
    stroke(0);
    strokeWeight(1);
    fill(125);
    beginShape();
    vertex(265 + x, 278 + y + h);
    vertex(290 + x, 278 + y + h);
    vertex(295 + x, 285 + y + h);
    vertex(340 + x, 285 + y + h);
    vertex(345 + x, 280 + y + h);
    vertex(375 + x, 280 + y + h);
    vertex(380 + x, 285 + y + h);
    vertex(375 + x, 290 + y + h);
    vertex(265 + x, 290 + y + h);
    vertex(265 + x, 278 + y + h);
    endShape();
  
    beginShape();
    vertex(265 + x, 295 + y + h);
    vertex(375 + x, 295 + y + h);
    vertex(380 + x, 297.5 + y + h);
    vertex(375 + x, 300 + y + h);
    vertex(290 + x, 300 + y + h);
    vertex(265 + x, 295 + y + h);
    endShape();
  
    fill(40);
    rect(355 + x, 285 + y + h, 40, 20);
  
    fill(235);
    rect(100 + x, 275 + y + h, 180, 40, 5, 25, 0, 0);
    fill(235);
    rect(100 + x, 315 + y + h, 180, 20, 0, 0, 25, 5);
    
    fill(220);
    ellipse(185 + x, 325 + y + h, 100, 20);
    beginShape();
    vertex(135 + x, 325 + y + h);
    vertex(133 + x, 305 + y + h);
    vertex(237 + x, 305 + y + h);
    vertex(235 + x, 325 + y + h);
    endShape();
  
    noStroke();
    fill(0, 20);
    rect(100 + x, 275 + y + h, 35, 60, 5, 10, 10, 5);
    
    //Cylindrical Piece
    fill(220);
    stroke(220);
    for(i = 0; i < 20; i++){
      if(i == 19){
        stroke(0);
      }
      ellipse(185 + x, 285 + y + h + i, 100 + i / 4, 20 + i / 4);
    }
  
    fill(220);
    stroke(0);
    beginShape();
    vertex(133 + x, 305 + y + h);
    vertex(135 + x, 285 + y + h);
    vertex(235 + x, 285 + y + h);
    vertex(237 + x, 305 + y + h);
    endShape();
   
    noStroke();
    fill(0, 20);
    rect(135 + x, 285 + y + h, 30, 45, 10);
    
    fill(235);
    strokeWeight(1);
    stroke(1);
    ellipse(185 + x, 285 + y + h, 100, 20);
    noStroke();
    fill(225);
    ellipse(185 + x, 285 + y + h, 85, 10);  
  
    stroke(0);
    strokeWeight(1)
    fill(40);
    beginShape();
    vertex(375 + x, 305 + y + h);
    vertex(420 + x, 304 + y + h);
    vertex(420 + x, 320 + y + h);
    vertex(375 + x, 320 + y + h);
    endShape();
  
    fill(20);
    beginShape();
    vertex(345 + x, 329 + y + h);
    vertex(345 + x, 325 + y + h);
    vertex(385 + x, 315 + y + h);
    vertex(420 + x, 315 + y + h);
    vertex(420 + x, 340 + y + h);
    vertex(385 + x, 338 + y + h);
    endShape();
  
    //Upper Left Arm
    stroke(0);
    strokeWeight(1);
    fill(125);
    beginShape();
    vertex(215 + x, 307 + y + h);
    vertex(255 + x, 312 + y + h);
    vertex(305 + x, 310 + y + h);
    vertex(355 + x, 312 + y + h);
    vertex(395 + x, 317 + y + h);
    vertex(395 + x, 327 + y + h);
    vertex(355 + x, 322 + y + h);
    vertex(305 + x, 320 + y + h);
    vertex(255 + x, 322 + y + h);
    vertex(215 + x, 317 + y + h);
    vertex(215 + x, 307 + y + h);
    endShape();
  
    fill(155);
    beginShape();
    vertex(215 + x, 307 + y + h);
    vertex(220 + x, 300 + y + h);
    vertex(255 + x, 305 + y + h);
    vertex(295 + x, 303 + y + h);
    vertex(305 + x, 308 + y + h);
    vertex(355 + x, 308 + y + h);
    vertex(365 + x, 303 + y + h);
    vertex(405 + x, 308 + y + h);
    vertex(395 + x, 313 + y + h);
    vertex(395 + x, 317 + y + h);
    vertex(355 + x, 312 + y + h);
    vertex(255 + x, 312 + y + h);
    vertex(215 + x, 307 + y + h);
    endShape();
  
    fill(165);
    beginShape();
    vertex(295 + x, 303 + y + h);
    vertex(255 + x, 305 + y + h);
    vertex(220 + x, 300 + y + h);
    vertex(230 + x, 290 + y + h);
    vertex(268 + x, 295 + y + h);
    vertex(295 + x, 303 + y + h);
    endShape();
  
    //Lower Left Arm
    stroke(0);
    strokeWeight(1);
    fill(125);
    beginShape();
    vertex(215 + x, 322 + y + h);
    vertex(255 + x, 327 + y + h);
    vertex(305 + x, 325 + y + h);
    vertex(355 + x, 327 + y + h);
    vertex(395 + x, 332 + y + h);
    vertex(395 + x, 340 + y + h);
    vertex(355 + x, 335 + y + h);
    vertex(305 + x, 333 + y + h);
    vertex(255 + x, 335 + y + h);
    vertex(215 + x, 330 + y + h);
    vertex(215 + x, 322 + y + h);
    endShape();
  
    //Shadows and Highlights
    noStroke();
    fill(0, 20);
    beginShape();
    vertex(255 + x, 312 + y + h);
    vertex(305 + x, 310 + y + h);
    vertex(305 + x, 320 + y + h);
    vertex(255 + x, 322 + y + h);
    endShape();
  
    beginShape();
    vertex(280 + x, 278 + y + h);
    vertex(290 + x, 278 + y + h);
    vertex(295 + x, 285 + y + h);
    vertex(340 + x, 285 + y + h);
    vertex(375 + x, 290 + y + h);
    vertex(280 + x, 290 + y + h);
    vertex(280 + x, 278 + y + h);
    endShape();
  
    beginShape();
    vertex(280 + x, 295 + y + h);
    vertex(375 + x, 295 + y + h);
    vertex(380 + x, 297.5 + y + h);
    vertex(375 + x, 300 + y + h);
    vertex(280 + x, 295 + y + h);
    endShape();
  
    noStroke();
    fill(0, 150);
    beginShape();
    vertex(215 + x, 317 + y + h);
    vertex(255 + x, 322 + y + h);
    vertex(305 + x, 320 + y + h);
    vertex(355 + x, 324 + y + h);
    vertex(395 + x, 329 + y + h);
    vertex(395 + x, 332 + y + h);
    vertex(355 + x, 327 + y + h);
    vertex(305 + x, 325 + y + h);
    vertex(255 + x, 327 + y + h);
    vertex(215 + x, 322 + y + h);
    vertex(215 + x, 319 + y + h);
    endShape();
  
    beginShape();
    vertex(280 + x, 290 + y + h);
    vertex(330 + x, 290 + y + h);
    vertex(377 + x, 295 + y + h);
    vertex(280 + x, 295 + y + h);
    endShape();
  
    fill(255, 20);
    beginShape();
    vertex(355 + x, 312 + y + h);
    vertex(395 + x, 317 + y + h);
    vertex(395 + x, 327 + y + h);
    vertex(355 + x, 322 + y + h);
    endShape();
  
    beginShape();
    vertex(355 + x, 308 + y + h);
    vertex(395 + x, 313 + y + h);
    vertex(395 + x, 317 + y + h);
    vertex(355 + x, 312 + y + h);
    endShape();
    
    fill(255, 30);
    beginShape();
    vertex(215 + x, 307 + y + h);
    vertex(255 + x, 312 + y + h);
    vertex(255 + x, 322 + y + h);
    vertex(215 + x, 317 + y + h);
    vertex(215 + x, 307 + y + h);
    endShape();
    
    fill(255, 255);
    arc(190 + x, 300 + y + h, 45, 10, 0, PI);
    arc(245 + x, 285 + y + h, 30, 10, PI + HALF_PI + QUARTER_PI, 0);
  }
    //Left Side
  if(keyIsDown(LEFT_ARROW) && !keyIsDown(RIGHT_ARROW) && screen != "intro"){
    //Left Arm
    stroke(0);
    strokeWeight(1);
    fill(125);
    beginShape();
    vertex(335 + x + t, 278 + y + h);
    vertex(310 + x + t, 278 + y + h);
    vertex(305 + x + t, 285 + y + h);
    vertex(260 + x + t, 285 + y + h);
    vertex(255 + x + t, 280 + y + h);
    vertex(225 + x + t, 280 + y + h);
    vertex(220 + x + t, 285 + y + h);
    vertex(225 + x + t, 290 + y + h);
    vertex(335 + x + t, 290 + y + h);
    vertex(335 + x + t, 278 + y + h);
    endShape();
  
    beginShape();
    vertex(335 + x + t, 295 + y + h);
    vertex(225 + x + t, 295 + y + h);
    vertex(220 + x + t, 297.5 + y + h);
    vertex(225 + x + t, 300 + y + h);
    vertex(310 + x + t, 300 + y + h);
    vertex(335 + x + t, 295 + y + h);
    endShape();
  
    fill(40);
    rect(205 + x + t, 285 + y + h, 40, 20);
  
    fill(235);
    rect(100 + x, 275 + y + h, 180, 40, 25, 5, 0, 0);
    fill(235);
    rect(100 + x, 315 + y + h, 180, 20, 0, 0, 5, 25);
    
    fill(220);
    ellipse(415 + x + t, 325 + y + h, 100, 20);
    beginShape();
    vertex(465 + x + t, 325 + y + h);
    vertex(467 + x + t, 305 + y + h);
    vertex(363 + x + t, 305 + y + h);
    vertex(365 + x + t, 325 + y + h);
    endShape();
  
    noStroke();
    fill(0, 20);
    rect(450 + x + t, 275 + y + h, 35, 60, 10, 5, 5, 10);
    
    //Cylindrical Piece
    fill(220);
    stroke(220);
    for(i = 0; i < 20; i++){
      if(i == 19){
        stroke(0);
      }
      ellipse(415 + x + t, 285 + y + h + i, 100 + i / 4, 20 + i / 4);
    }
  
    fill(220);
    stroke(0);
    beginShape();
    vertex(467 + x + t, 305 + y + h);
    vertex(465 + x + t, 285 + y + h);
    vertex(365 + x + t, 285 + y + h);
    vertex(363 + x + t, 305 + y + h);
    endShape();
   
    noStroke();
    fill(0, 20);
    rect(435 + x + t, 285 + y + h, 30, 45, 10);
    
    fill(235);
    strokeWeight(1);
    stroke(1);
    ellipse(415 + x + t, 285 + y + h, 100, 20);
    noStroke();
    fill(225);
    ellipse(415 + x + t, 285 + y + h, 85, 10);  
  
    stroke(0);
    strokeWeight(1)
    fill(40);
    beginShape();
    vertex(225 + x + t, 305 + y + h);
    vertex(180 + x + t, 304 + y + h);
    vertex(180 + x + t, 320 + y + h);
    vertex(225 + x + t, 320 + y + h);
    endShape();
  
    fill(20);
    beginShape();
    vertex(255 + x + t, 329 + y + h);
    vertex(255 + x + t, 325 + y + h);
    vertex(215 + x + t, 315 + y + h);
    vertex(180 + x + t, 315 + y + h);
    vertex(180 + x + t, 340 + y + h);
    vertex(215 + x + t, 338 + y + h);
    endShape();
  
    //Upper Right Arm
    stroke(0);
    strokeWeight(1);
    fill(125);
    beginShape();
    vertex(385 + x + t, 307 + y + h);
    vertex(345 + x + t, 312 + y + h);
    vertex(295 + x + t, 310 + y + h);
    vertex(245 + x + t, 312 + y + h);
    vertex(205 + x + t, 317 + y + h);
    vertex(205 + x + t, 327 + y + h);
    vertex(245 + x + t, 322 + y + h);
    vertex(295 + x + t, 320 + y + h);
    vertex(345 + x + t, 322 + y + h);
    vertex(385 + x + t, 317 + y + h);
    vertex(385 + x + t, 307 + y + h);
    endShape();
  
    fill(155);
    beginShape();
    vertex(385 + x + t, 307 + y + h);
    vertex(380 + x + t, 300 + y + h);
    vertex(345 + x + t, 305 + y + h);
    vertex(305 + x + t, 303 + y + h);
    vertex(295 + x + t, 308 + y + h);
    vertex(245 + x + t, 308 + y + h);
    vertex(235 + x + t, 303 + y + h);
    vertex(195 + x + t, 308 + y + h);
    vertex(205 + x + t, 313 + y + h);
    vertex(205 + x + t, 317 + y + h);
    vertex(245 + x + t, 312 + y + h);
    vertex(345 + x + t, 312 + y + h);
    vertex(385 + x + t, 307 + y + h);
    endShape();
  
    fill(165);
    beginShape();
    vertex(305 + x + t, 303 + y + h);
    vertex(345 + x + t, 305 + y + h);
    vertex(380 + x + t, 300 + y + h);
    vertex(370 + x + t, 290 + y + h);
    vertex(332 + x + t, 295 + y + h);
    vertex(305 + x + t, 303 + y + h);
    endShape();
  
    //Lower Right Arm
    stroke(0);
    strokeWeight(1);
    fill(125);
    beginShape();
    vertex(385 + x + t, 322 + y + h);
    vertex(345 + x + t, 327 + y + h);
    vertex(295 + x + t, 325 + y + h);
    vertex(245 + x + t, 327 + y + h);
    vertex(205 + x + t, 332 + y + h);
    vertex(205 + x + t, 340 + y + h);
    vertex(245 + x + t, 335 + y + h);
    vertex(295 + x + t, 333 + y + h);
    vertex(345 + x + t, 335 + y + h);
    vertex(385 + x + t, 330 + y + h);
    vertex(385 + x + t, 322 + y + h);
    endShape();
  
    //Shadows and Highlights
    noStroke();
    fill(0, 20);
    beginShape();
    vertex(345 + x + t, 312 + y + h);
    vertex(295 + x + t, 310 + y + h);
    vertex(295 + x + t, 320 + y + h);
    vertex(345 + x + t, 322 + y + h);
    endShape();
  
    beginShape();
    vertex(305 + x + t, 278 + y + h);
    vertex(310 + x + t, 278 + y + h);
    vertex(305 + x + t, 285 + y + h);
    vertex(260 + x + t, 285 + y + h);
    vertex(225 + x + t, 290 + y + h);
    vertex(305 + x + t, 290 + y + h);
    vertex(305 + x + t, 278 + y + h);
    endShape();
  
    beginShape();
    vertex(320 + x + t, 295 + y + h);
    vertex(225 + x + t, 295 + y + h);
    vertex(220 + x + t, 297.5 + y + h);
    vertex(225 + x + t, 300 + y + h);
    vertex(320 + x + t, 295 + y + h);
    endShape();
  
    noStroke();
    fill(0, 150);
    beginShape();
    vertex(385 + x + t, 317 + y + h);
    vertex(345 + x + t, 322 + y + h);
    vertex(295 + x + t, 320 + y + h);
    vertex(245 + x + t, 324 + y + h);
    vertex(205 + x + t, 329 + y + h);
    vertex(205 + x + t, 332 + y + h);
    vertex(245 + x + t, 327 + y + h);
    vertex(295 + x + t, 325 + y + h);
    vertex(345 + x + t, 327 + y + h);
    vertex(385 + x + t, 322 + y + h);
    vertex(385 + x + t, 319 + y + h);
    endShape();
  
    beginShape();
    vertex(305 + x + t, 290 + y + h);
    vertex(270 + x + t, 290 + y + h);
    vertex(223 + x + t, 295 + y + h);
    vertex(305 + x + t, 295 + y + h);
    endShape();
  
    fill(255, 20);
    beginShape();
    vertex(245 + x + t, 312 + y + h);
    vertex(205 + x + t, 317 + y + h);
    vertex(205 + x + t, 327 + y + h);
    vertex(245 + x + t, 322 + y + h);
    endShape();
  
    beginShape();
    vertex(245 + x + t, 308 + y + h);
    vertex(205 + x + t, 313 + y + h);
    vertex(205 + x + t, 317 + y + h);
    vertex(245 + x + t, 312 + y + h);
    endShape();
    
    fill(255, 30);
    beginShape();
    vertex(385 + x + t, 307 + y + h);
    vertex(345 + x + t, 312 + y + h);
    vertex(345 + x + t, 322 + y + h);
    vertex(385 + x + t, 317 + y + h);
    vertex(385 + x + t, 307 + y + h);
    endShape();
    
    fill(255, 255);
    arc(410 + x + t, 300 + y + h, 45, 10, 0, PI);
    arc(335 + x + t, 285 + y + h, 30, 10, PI, PI + HALF_PI + QUARTER_PI);
  }
}
function drawRob(x, y, h){
  //Face
  stroke(0);
  strokeWeight(1);
  fill(random(255, 0), 0, 0);
  ellipse(200 + x, 100 + y, 10, 15);
  
  fill(225);
  rect(195 + x, 98 + y, 10, 5);
  rect(95 + x, 120 + y, 10, 60, 10);
  rect(295 + x, 120 + y, 10, 60, 10);

  rect(100 + x, 100 + y, 200, 100, 10);
  
  fill(40);
  rect(107 + x, 107 + y, 186, 86, 10);
  
  strokeWeight(2);
  fill(30);
  rect(115 + x, 115 + y, 170, 70, 20);
  
  fill(0);
  stroke(0);
  strokeWeight(5);
  line(150 + x, 135 + y, 250 + x, 135 + y);
  line(150 + x, 150 + y, 250 + x, 150 + y);
  line(150 + x, 165 + y, 250 + x, 165 + y);
  
  //Eyes
  fill(0);
  stroke(0);
  strokeWeight(1);
  ellipse(150 + x, 150 + y, 60, 60);
  ellipse(250 + x, 150 + y, 60, 60);
  
  //Lighting for Eyes
  fill(255, 175);
  noStroke();
  ellipse(160 + x, 135 + y, 10, 10);
  ellipse(260 + x, 135 + y, 10, 10);
  
  //Eye Reflection
  for(var i = 0; i <= 5; i++){
    fill(125 - i * 25, 150);
    arc(150 + x, 150 + y, 60 - i * 5, 60 - i * 5, 70, 650);
    fill(0);
    arc(150 + x, 150 + y, 55 - i * 5, 55 - i * 5, 70, 650);
    fill(125 - i * 25, 150);
    arc(250 + x, 150 + y, 60 - i * 5, 60 - i * 5, 70, 650);
    fill(0);
    arc(250 + x, 150 + y, 55 - i * 5, 55 - i * 5, 70, 650);
  }
  
  //Neck
  stroke(0);
  strokeWeight(1);
  fill(205);
  rect(170 + x, 200 + y, 60, 5);
  rect(170 + x, 205 + y, 15, 15);
  rect(195 + x, 205 + y, 10, 15);
  rect(215 + x, 205 + y, 15, 15);
  rect(170 + x, 215 + y, 60, 5);
  fill(235);
  
  //Base
  stroke(0);
  strokeWeight(1);
  fill(210);
  beginShape();
  vertex(330 + x, 425 + y);
  vertex(330 + x, 455 + y);
  vertex(275 + x, 535 + y);
  vertex(125 + x, 535 + y);
  vertex(70 + x, 455 + y);
  vertex(70 + x, 425 + y);
  vertex(330 + x, 425 + y);
  endShape();
  
  stroke(0);
  strokeWeight(1);
  fill(240);
  beginShape();
  vertex(70 + x, 425 + y);
  vertex(125 + x, 505 + y);
  vertex(275 + x, 505 + y);
  vertex(330 + x, 425 + y);
  vertex(275 + x, 380 + y);
  vertex(125 + x, 380 + y);
  vertex(70 + x, 425 + y);
  endShape();
  
  fill(230);
  for(i = 0; i < 5; i++){
    ellipse(200 + x, 425 + y + i, 175, 75);
  }
  fill(235);
  ellipse(200 + x, 425 + y, 175, 75);
  fill(220);
  for(i = 0; i < 5; i++){
    ellipse(200 + x, 420 + y + i, 125, 50);
  }
  fill(235);
  ellipse(200 + x, 420 + y, 125, 50);  
  
  fill(230);
  for(i = 0; i < 5; i++){
    beginShape();
    vertex(250 + x, 455 + y + i);
    vertex(255 + x, 510 + y + i);
    vertex(220 + x, 510 + y + i);
    vertex(220 + x, 485 + y + i);
    vertex(180 + x, 485 + y + i);
    vertex(180 + x, 510 + y + i);
    vertex(145 + x, 510 + y + i);
    vertex(150 + x, 455 + y + i);
    endShape();
  }
  fill(235);
  beginShape();
  vertex(250 + x, 455 + y);
  vertex(255 + x, 510 + y);
  vertex(220 + x, 510 + y);
  vertex(220 + x, 485 + y);
  vertex(180 + x, 485 + y);
  vertex(180 + x, 510 + y);
  vertex(145 + x, 510 + y);
  vertex(150 + x, 455 + y);
  endShape();
  
  fill(220);
  stroke(0);
  rect(145 + x, 510 + y, 35, 30);
  rect(220 + x, 510 + y, 35, 30);
  
  noStroke();
  fill(100, 20)
  beginShape();
  vertex(320 + x, 425 + y);
  vertex(80 + x, 425 + y);
  vertex(125 + x, 380 + y);
  vertex(275 + x, 380 + y);
  vertex(320 + x, 425 + y);
  endShape();
  
  // Spine
  stroke(0);
  fill(225);
  rect(175 + x, 220 + y, 50, 200);
  fill(230);
  rect(185 + x, 220 + y, 30, 200);
  for(i = 0; i  < 200; i += 2){
    strokeWeight(0.5);
    line(180 + x, 220 + i + y, 185 + x, 220 + i + y);
    line(215 + x, 220 + i + y, 220 + x, 220 + i + y);
  }
  
  noFill();
  stroke(220);
  strokeWeight(3);
  for(i = 1; i < 40; i++){
    arc(200 + x, 375 + y + i, 60, 20, radians(350), radians(190));
  }
  
  stroke(0);
  strokeWeight(1);
  arc(200 + x, 375 + y, 60, 20, radians(350), radians(190));
  arc(200 + x, 415 + y, 60, 20, radians(360), radians(180));
  line(170 + x, 375 + y, 170 + x, 415 + y);
  line(230 + x, 375 + y, 230 + x, 415 + y);
  
  //Upper Body
    //Straight View
  if((keyIsDown(LEFT_ARROW) && keyIsDown(RIGHT_ARROW)) || (!keyIsDown(LEFT_ARROW) && !keyIsDown(RIGHT_ARROW)) && !(robLeft || robRight || robUp)){
    stroke(0);
    strokeWeight(1)
    fill(235);
    ellipse(70 + x, 305 + y + h, 90, 60);
    ellipse(330 + x, 305 + y + h, 90, 60);
  
    noStroke();
    fill(40);
    rect(40 + x, 285 + y + h, 50, 40, 10);
    rect(310 + x, 285 + y + h, 50, 40, 10);

    stroke(0);
    strokeWeight(1);
    fill(235);
    rect(80 + x, 275 + y + h, 240, 40, 20, 20, 0, 0);
    fill(235);
    rect(80 + x, 315 + y + h, 240, 20, 0, 0, 10, 10);
    fill(205);
    rect(160 + x, 275 + y + h , 80, 30, 3, 3, 10, 10);
    noStroke();
    fill(0, 20);
    rect(95 + x, 275 + y + h, 210, 40 - (h / 3 + 20), 10);
  
    //Arms
    //Left Clamp
    stroke(0);
    strokeWeight(1);
    fill(40);
    for(i = 0; i < 20; i++){
      rect(20 + x, 377 + y + h + i, 130, 20, 5, 10, 10, 10);
    }
    fill(60);
    rect(20 + x, 377 + y + h, 130, 20, 5, 10, 10, 10);
  
    fill(155);
    beginShape();
    vertex(85 + x, 395 + y + h);
    vertex(140 + x, 375 + y + h);
    vertex(155 + x, 375 + y + h);
    vertex(145 + x, 405 + y + h);
    vertex(80 + x, 400 + y + h);
    vertex(85 + x, 395 + y + h);
    endShape();
  
    fill(145);
    beginShape();
    vertex(80 + x, 400 + y + h);
    vertex(145 + x, 405 + y + h);
    vertex(145 + x, 425 + y + h);
    vertex(80 + x, 420 + y + h);
    vertex(80 + x, 400 + y + h);
    endShape();
  
    fill(0);
    beginShape();
    vertex(145 + x, 425 + y + h);
    vertex(145 + x, 405 + y + h);
    vertex(155 + x, 375 + y + h);
    vertex(155 + x, 395 + y + h);
    vertex(145 + x, 425 + y + h);
    endShape();
  
    //Left Arm
    fill(75);
    for(i = 0; i < 5; i++){
      arc(80 + x - i, 385 + y + h + i, 20, 20, 0, PI);
      beginShape();
      vertex(70 + x - i, 385 + y + h + i);
      vertex(75 + x - i, 365 + y + h + i);  
      vertex(75 + x - i, 365 + y + h + i);
      vertex(50 + x - i, 320 + y + h + i);
      vertex(70 + x - i, 320 + y + h + i);
      vertex(95 + x - i, 365 + y + h + i);
      vertex(90 + x - i, 385 + y + h + i);
      endShape();
    
      beginShape();
      vertex(59 + x - i , 335 + y + h + i);
      vertex(28 + x - i, 320 + y + h + i);
      vertex(40 + x - i, 287 + y + h + i);
      vertex(77 + x - i, 290 + y + h + i);
      vertex(74 + x - i, 325 + y + h + i);
      endShape();
    }
    fill(155);
    stroke(1);
    strokeWeight(1);
    arc(80 + x, 385 + y + h, 20, 20, 0, PI);
    beginShape();
    vertex(70 + x, 385 + y + h);
    vertex(75 + x, 365 + y + h);  
    vertex(75 + x, 365 + y + h);
    vertex(50 + x, 320 + y + h);
    vertex(70 + x, 320 + y + h);
    vertex(95 + x, 365 + y + h);
    vertex(90 + x, 385 + y + h);
    endShape();
    
    beginShape();
    vertex(59 + x, 335 + y + h);
    vertex(28 + x, 320 + y + h);
    vertex(40 + x, 287 + y + h );
    vertex(77 + x, 290 + y + h);
    vertex(74 + x, 325 + y + h);
    endShape();

    //Right Clamp
    fill(40);
    for(i = 0; i < 20; i++){
      rect(250 + x, 377 + y + h + i, 130, 20, 10, 5, 10, 10);
    }
    fill(60);
    rect(250 + x, 377 + y + h, 130, 20, 10, 5, 10, 10);
      
    fill(40);
    for(i = 0; i < 5; i++){
      ellipse(350 + x, 385 + y + h + i, 10, 5);
      ellipse(320 + x, 385 + y + h + i, 10, 5);
    }
    fill(60);
    ellipse(350 + x, 385 + y + h, 10, 5);
    ellipse(320 + x, 385 + y + h, 10, 5);
  
    fill(155);
    beginShape();
    vertex(315 + x, 395 + y + h);
    vertex(255 + x, 375 + y + h);
    vertex(245 + x, 375 + y + h);
    vertex(255 + x, 405 + y + h);
    vertex(320 + x, 400 + y + h);
    vertex(315 + x, 395 + y + h);
    endShape();
  
    fill(145);
    beginShape();
    vertex(320 + x, 400 + y + h);
    vertex(255 + x, 405 + y + h);
    vertex(255 + x, 425 + y + h);
    vertex(320 + x, 420 + y + h);
    vertex(320 + x, 400 + y + h);
    endShape();
  
    fill(0);
    beginShape();
    vertex(255 + x, 425 + y + h);
    vertex(245 + x, 395 + y + h);
    vertex(245 + x, 375 + y + h);
    vertex(255 + x, 405 + y + h);
    vertex(255 + x, 425 + y + h);
    endShape();
  
  
    //Right Arm
    fill(75);
    for(i = 0; i < 5; i++){
      arc(320 + x + i, 385 + y + h + i, 20, 20, 0, PI);
      beginShape();
      vertex(330 + x + i, 385 + y + h + i);
      vertex(325 + x + i, 365 + y + h + i);  
      vertex(325 + x + i, 365 + y + h + i);
      vertex(350 + x + i, 320 + y + h + i);
      vertex(330 + x + i, 320 + y + h + i);
      vertex(305 + x + i, 365 + y + h + i);
      vertex(310 + x + i, 385 + y + h + i);
      endShape();
    
      beginShape();
      vertex(341 + x + i, 335 + y + h + i);
      vertex(372 + x + i, 320 + y + h + i);
      vertex(360 + x + i, 287 + y + h + i);
      vertex(323 + x + i, 290 + y + h + i);
      vertex(326 + x + i, 325 + y + h + i);
      endShape();
    }
    fill(155);
    stroke(1);
    strokeWeight(1);
    arc(320 + x, 385 + y + h, 20, 20, 0, PI);
    beginShape();
    vertex(330 + x, 385 + y + h);
    vertex(325 + x, 365 + y + h);  
    vertex(325 + x, 365 + y + h);
    vertex(350 + x, 320 + y + h);
    vertex(330 + x, 320 + y + h);
    vertex(305 + x, 365 + y + h);
    vertex(310 + x, 385 + y + h);
    endShape();
  
    beginShape();
    vertex(341 + x, 335 + y + h + i);
    vertex(372 + x, 320 + y + h + i);
    vertex(360 + x, 287 + y + h + i);
    vertex(323 + x, 290 + y + h + i);
    vertex(326 + x, 325 + y + h + i);
    endShape();
  
    //Extra Design on Arm
    fill(60);
    ellipse(50 + x, 385 + y + h, 10, 5);
    ellipse(80 + x, 385 + y + h, 10, 5);
    ellipse(350 + x, 385 + y + h, 10, 5);
    ellipse(320 + x, 385 + y + h, 10, 5);
  }
  
    //Right View
  if(((keyIsDown(RIGHT_ARROW) && !keyIsDown(LEFT_ARROW)) && !(robLeft || robDown || robUp)) || robRight){
    //Right Arm
    stroke(0);
    strokeWeight(1);
    fill(125);
    beginShape();
    vertex(265 + x, 278 + y + h);
    vertex(290 + x, 278 + y + h);
    vertex(295 + x, 285 + y + h);
    vertex(340 + x, 285 + y + h);
    vertex(345 + x, 280 + y + h);
    vertex(375 + x, 280 + y + h);
    vertex(380 + x, 285 + y + h);
    vertex(375 + x, 290 + y + h);
    vertex(265 + x, 290 + y + h);
    vertex(265 + x, 278 + y + h);
    endShape();
  
    beginShape();
    vertex(265 + x, 295 + y + h);
    vertex(375 + x, 295 + y + h);
    vertex(380 + x, 297.5 + y + h);
    vertex(375 + x, 300 + y + h);
    vertex(290 + x, 300 + y + h);
    vertex(265 + x, 295 + y + h);
    endShape();
  
    fill(40);
    rect(355 + x, 285 + y + h, 40, 20);
  
    fill(235);
    rect(100 + x, 275 + y + h, 180, 40, 5, 25, 0, 0);
    fill(235);
    rect(100 + x, 315 + y + h, 180, 20, 0, 0, 25, 5);
    
    fill(220);
    ellipse(185 + x, 325 + y + h, 100, 20);
    beginShape();
    vertex(135 + x, 325 + y + h);
    vertex(133 + x, 305 + y + h);
    vertex(237 + x, 305 + y + h);
    vertex(235 + x, 325 + y + h);
    endShape();
  
    noStroke();
    fill(0, 20);
    rect(100 + x, 275 + y + h, 35, 60, 5, 10, 10, 5);
    
    //Cylindrical Piece
    fill(220);
    stroke(220);
    for(i = 0; i < 20; i++){
      if(i == 19){
        stroke(0);
      }
      ellipse(185 + x, 285 + y + h + i, 100 + i / 4, 20 + i / 4);
    }
  
    fill(220);
    stroke(0);
    beginShape();
    vertex(133 + x, 305 + y + h);
    vertex(135 + x, 285 + y + h);
    vertex(235 + x, 285 + y + h);
    vertex(237 + x, 305 + y + h);
    endShape();
   
    noStroke();
    fill(0, 20);
    rect(135 + x, 285 + y + h, 30, 45, 10);
    
    fill(235);
    strokeWeight(1);
    stroke(1);
    ellipse(185 + x, 285 + y + h, 100, 20);
    noStroke();
    fill(225);
    ellipse(185 + x, 285 + y + h, 85, 10);  
  
    stroke(0);
    strokeWeight(1)
    fill(40);
    beginShape();
    vertex(375 + x, 305 + y + h);
    vertex(420 + x, 304 + y + h);
    vertex(420 + x, 320 + y + h);
    vertex(375 + x, 320 + y + h);
    endShape();
  
    fill(20);
    beginShape();
    vertex(345 + x, 329 + y + h);
    vertex(345 + x, 325 + y + h);
    vertex(385 + x, 315 + y + h);
    vertex(420 + x, 315 + y + h);
    vertex(420 + x, 340 + y + h);
    vertex(385 + x, 338 + y + h);
    endShape();
  
    //Upper Left Arm
    stroke(0);
    strokeWeight(1);
    fill(125);
    beginShape();
    vertex(215 + x, 307 + y + h);
    vertex(255 + x, 312 + y + h);
    vertex(305 + x, 310 + y + h);
    vertex(355 + x, 312 + y + h);
    vertex(395 + x, 317 + y + h);
    vertex(395 + x, 327 + y + h);
    vertex(355 + x, 322 + y + h);
    vertex(305 + x, 320 + y + h);
    vertex(255 + x, 322 + y + h);
    vertex(215 + x, 317 + y + h);
    vertex(215 + x, 307 + y + h);
    endShape();
  
    fill(155);
    beginShape();
    vertex(215 + x, 307 + y + h);
    vertex(220 + x, 300 + y + h);
    vertex(255 + x, 305 + y + h);
    vertex(295 + x, 303 + y + h);
    vertex(305 + x, 308 + y + h);
    vertex(355 + x, 308 + y + h);
    vertex(365 + x, 303 + y + h);
    vertex(405 + x, 308 + y + h);
    vertex(395 + x, 313 + y + h);
    vertex(395 + x, 317 + y + h);
    vertex(355 + x, 312 + y + h);
    vertex(255 + x, 312 + y + h);
    vertex(215 + x, 307 + y + h);
    endShape();
  
    fill(165);
    beginShape();
    vertex(295 + x, 303 + y + h);
    vertex(255 + x, 305 + y + h);
    vertex(220 + x, 300 + y + h);
    vertex(230 + x, 290 + y + h);
    vertex(268 + x, 295 + y + h);
    vertex(295 + x, 303 + y + h);
    endShape();
  
    //Lower Left Arm
    stroke(0);
    strokeWeight(1);
    fill(125);
    beginShape();
    vertex(215 + x, 322 + y + h);
    vertex(255 + x, 327 + y + h);
    vertex(305 + x, 325 + y + h);
    vertex(355 + x, 327 + y + h);
    vertex(395 + x, 332 + y + h);
    vertex(395 + x, 340 + y + h);
    vertex(355 + x, 335 + y + h);
    vertex(305 + x, 333 + y + h);
    vertex(255 + x, 335 + y + h);
    vertex(215 + x, 330 + y + h);
    vertex(215 + x, 322 + y + h);
    endShape();
  
    //Shadows and Highlights
    noStroke();
    fill(0, 20);
    beginShape();
    vertex(255 + x, 312 + y + h);
    vertex(305 + x, 310 + y + h);
    vertex(305 + x, 320 + y + h);
    vertex(255 + x, 322 + y + h);
    endShape();
  
    beginShape();
    vertex(280 + x, 278 + y + h);
    vertex(290 + x, 278 + y + h);
    vertex(295 + x, 285 + y + h);
    vertex(340 + x, 285 + y + h);
    vertex(375 + x, 290 + y + h);
    vertex(280 + x, 290 + y + h);
    vertex(280 + x, 278 + y + h);
    endShape();
  
    beginShape();
    vertex(280 + x, 295 + y + h);
    vertex(375 + x, 295 + y + h);
    vertex(380 + x, 297.5 + y + h);
    vertex(375 + x, 300 + y + h);
    vertex(280 + x, 295 + y + h);
    endShape();
  
    noStroke();
    fill(0, 150);
    beginShape();
    vertex(215 + x, 317 + y + h);
    vertex(255 + x, 322 + y + h);
    vertex(305 + x, 320 + y + h);
    vertex(355 + x, 324 + y + h);
    vertex(395 + x, 329 + y + h);
    vertex(395 + x, 332 + y + h);
    vertex(355 + x, 327 + y + h);
    vertex(305 + x, 325 + y + h);
    vertex(255 + x, 327 + y + h);
    vertex(215 + x, 322 + y + h);
    vertex(215 + x, 319 + y + h);
    endShape();
  
    beginShape();
    vertex(280 + x, 290 + y + h);
    vertex(330 + x, 290 + y + h);
    vertex(377 + x, 295 + y + h);
    vertex(280 + x, 295 + y + h);
    endShape();
  
    fill(255, 20);
    beginShape();
    vertex(355 + x, 312 + y + h);
    vertex(395 + x, 317 + y + h);
    vertex(395 + x, 327 + y + h);
    vertex(355 + x, 322 + y + h);
    endShape();
  
    beginShape();
    vertex(355 + x, 308 + y + h);
    vertex(395 + x, 313 + y + h);
    vertex(395 + x, 317 + y + h);
    vertex(355 + x, 312 + y + h);
    endShape();
    
    fill(255, 30);
    beginShape();
    vertex(215 + x, 307 + y + h);
    vertex(255 + x, 312 + y + h);
    vertex(255 + x, 322 + y + h);
    vertex(215 + x, 317 + y + h);
    vertex(215 + x, 307 + y + h);
    endShape();
    
    fill(255, 255);
    arc(190 + x, 300 + y + h, 45, 10, 0, PI);
    arc(245 + x, 285 + y + h, 30, 10, PI + HALF_PI + QUARTER_PI, 0);
  }
  
    //Left Side
  if(((keyIsDown(LEFT_ARROW) && !keyIsDown(RIGHT_ARROW)) && !(robRight || robDown || robUp)) || robLeft){
    //Left Arm
    stroke(0);
    strokeWeight(1);
    fill(125);
    beginShape();
    vertex(335 + x + t, 278 + y + h);
    vertex(310 + x + t, 278 + y + h);
    vertex(305 + x + t, 285 + y + h);
    vertex(260 + x + t, 285 + y + h);
    vertex(255 + x + t, 280 + y + h);
    vertex(225 + x + t, 280 + y + h);
    vertex(220 + x + t, 285 + y + h);
    vertex(225 + x + t, 290 + y + h);
    vertex(335 + x + t, 290 + y + h);
    vertex(335 + x + t, 278 + y + h);
    endShape();
  
    beginShape();
    vertex(335 + x + t, 295 + y + h);
    vertex(225 + x + t, 295 + y + h);
    vertex(220 + x + t, 297.5 + y + h);
    vertex(225 + x + t, 300 + y + h);
    vertex(310 + x + t, 300 + y + h);
    vertex(335 + x + t, 295 + y + h);
    endShape();
  
    fill(40);
    rect(205 + x + t, 285 + y + h, 40, 20);
  
    fill(235);
    rect(100 + x, 275 + y + h, 180, 40, 25, 5, 0, 0);
    fill(235);
    rect(100 + x, 315 + y + h, 180, 20, 0, 0, 5, 25);
    
    fill(220);
    ellipse(415 + x + t, 325 + y + h, 100, 20);
    beginShape();
    vertex(465 + x + t, 325 + y + h);
    vertex(467 + x + t, 305 + y + h);
    vertex(363 + x + t, 305 + y + h);
    vertex(365 + x + t, 325 + y + h);
    endShape();
  
    noStroke();
    fill(0, 20);
    rect(450 + x + t, 275 + y + h, 35, 60, 10, 5, 5, 10);
    
    //Cylindrical Piece
    fill(220);
    stroke(220);
    for(i = 0; i < 20; i++){
      if(i == 19){
        stroke(0);
      }
      ellipse(415 + x + t, 285 + y + h + i, 100 + i / 4, 20 + i / 4);
    }
  
    fill(220);
    stroke(0);
    beginShape();
    vertex(467 + x + t, 305 + y + h);
    vertex(465 + x + t, 285 + y + h);
    vertex(365 + x + t, 285 + y + h);
    vertex(363 + x + t, 305 + y + h);
    endShape();
   
    noStroke();
    fill(0, 20);
    rect(435 + x + t, 285 + y + h, 30, 45, 10);
    
    fill(235);
    strokeWeight(1);
    stroke(1);
    ellipse(415 + x + t, 285 + y + h, 100, 20);
    noStroke();
    fill(225);
    ellipse(415 + x + t, 285 + y + h, 85, 10);  
  
    stroke(0);
    strokeWeight(1)
    fill(40);
    beginShape();
    vertex(225 + x + t, 305 + y + h);
    vertex(180 + x + t, 304 + y + h);
    vertex(180 + x + t, 320 + y + h);
    vertex(225 + x + t, 320 + y + h);
    endShape();
  
    fill(20);
    beginShape();
    vertex(255 + x + t, 329 + y + h);
    vertex(255 + x + t, 325 + y + h);
    vertex(215 + x + t, 315 + y + h);
    vertex(180 + x + t, 315 + y + h);
    vertex(180 + x + t, 340 + y + h);
    vertex(215 + x + t, 338 + y + h);
    endShape();
  
    //Upper Right Arm
    stroke(0);
    strokeWeight(1);
    fill(125);
    beginShape();
    vertex(385 + x + t, 307 + y + h);
    vertex(345 + x + t, 312 + y + h);
    vertex(295 + x + t, 310 + y + h);
    vertex(245 + x + t, 312 + y + h);
    vertex(205 + x + t, 317 + y + h);
    vertex(205 + x + t, 327 + y + h);
    vertex(245 + x + t, 322 + y + h);
    vertex(295 + x + t, 320 + y + h);
    vertex(345 + x + t, 322 + y + h);
    vertex(385 + x + t, 317 + y + h);
    vertex(385 + x + t, 307 + y + h);
    endShape();
  
    fill(155);
    beginShape();
    vertex(385 + x + t, 307 + y + h);
    vertex(380 + x + t, 300 + y + h);
    vertex(345 + x + t, 305 + y + h);
    vertex(305 + x + t, 303 + y + h);
    vertex(295 + x + t, 308 + y + h);
    vertex(245 + x + t, 308 + y + h);
    vertex(235 + x + t, 303 + y + h);
    vertex(195 + x + t, 308 + y + h);
    vertex(205 + x + t, 313 + y + h);
    vertex(205 + x + t, 317 + y + h);
    vertex(245 + x + t, 312 + y + h);
    vertex(345 + x + t, 312 + y + h);
    vertex(385 + x + t, 307 + y + h);
    endShape();
  
    fill(165);
    beginShape();
    vertex(305 + x + t, 303 + y + h);
    vertex(345 + x + t, 305 + y + h);
    vertex(380 + x + t, 300 + y + h);
    vertex(370 + x + t, 290 + y + h);
    vertex(332 + x + t, 295 + y + h);
    vertex(305 + x + t, 303 + y + h);
    endShape();
  
    //Lower Right Arm
    stroke(0);
    strokeWeight(1);
    fill(125);
    beginShape();
    vertex(385 + x + t, 322 + y + h);
    vertex(345 + x + t, 327 + y + h);
    vertex(295 + x + t, 325 + y + h);
    vertex(245 + x + t, 327 + y + h);
    vertex(205 + x + t, 332 + y + h);
    vertex(205 + x + t, 340 + y + h);
    vertex(245 + x + t, 335 + y + h);
    vertex(295 + x + t, 333 + y + h);
    vertex(345 + x + t, 335 + y + h);
    vertex(385 + x + t, 330 + y + h);
    vertex(385 + x + t, 322 + y + h);
    endShape();
  
    //Shadows and Highlights
    noStroke();
    fill(0, 20);
    beginShape();
    vertex(345 + x + t, 312 + y + h);
    vertex(295 + x + t, 310 + y + h);
    vertex(295 + x + t, 320 + y + h);
    vertex(345 + x + t, 322 + y + h);
    endShape();
  
    beginShape();
    vertex(305 + x + t, 278 + y + h);
    vertex(310 + x + t, 278 + y + h);
    vertex(305 + x + t, 285 + y + h);
    vertex(260 + x + t, 285 + y + h);
    vertex(225 + x + t, 290 + y + h);
    vertex(305 + x + t, 290 + y + h);
    vertex(305 + x + t, 278 + y + h);
    endShape();
  
    beginShape();
    vertex(320 + x + t, 295 + y + h);
    vertex(225 + x + t, 295 + y + h);
    vertex(220 + x + t, 297.5 + y + h);
    vertex(225 + x + t, 300 + y + h);
    vertex(320 + x + t, 295 + y + h);
    endShape();
  
    noStroke();
    fill(0, 150);
    beginShape();
    vertex(385 + x + t, 317 + y + h);
    vertex(345 + x + t, 322 + y + h);
    vertex(295 + x + t, 320 + y + h);
    vertex(245 + x + t, 324 + y + h);
    vertex(205 + x + t, 329 + y + h);
    vertex(205 + x + t, 332 + y + h);
    vertex(245 + x + t, 327 + y + h);
    vertex(295 + x + t, 325 + y + h);
    vertex(345 + x + t, 327 + y + h);
    vertex(385 + x + t, 322 + y + h);
    vertex(385 + x + t, 319 + y + h);
    endShape();
  
    beginShape();
    vertex(305 + x + t, 290 + y + h);
    vertex(270 + x + t, 290 + y + h);
    vertex(223 + x + t, 295 + y + h);
    vertex(305 + x + t, 295 + y + h);
    endShape();
  
    fill(255, 20);
    beginShape();
    vertex(245 + x + t, 312 + y + h);
    vertex(205 + x + t, 317 + y + h);
    vertex(205 + x + t, 327 + y + h);
    vertex(245 + x + t, 322 + y + h);
    endShape();
  
    beginShape();
    vertex(245 + x + t, 308 + y + h);
    vertex(205 + x + t, 313 + y + h);
    vertex(205 + x + t, 317 + y + h);
    vertex(245 + x + t, 312 + y + h);
    endShape();
    
    fill(255, 30);
    beginShape();
    vertex(385 + x + t, 307 + y + h);
    vertex(345 + x + t, 312 + y + h);
    vertex(345 + x + t, 322 + y + h);
    vertex(385 + x + t, 317 + y + h);
    vertex(385 + x + t, 307 + y + h);
    endShape();
    
    fill(255, 255);
    arc(410 + x + t, 300 + y + h, 45, 10, 0, PI);
    arc(335 + x + t, 285 + y + h, 30, 10, PI, PI + HALF_PI + QUARTER_PI);
  }
  
  //Arms Up
  if(robUp && !(robLeft || robRight || robDown)){
    stroke(0);
    strokeWeight(1)
    fill(235);
    ellipse(70 + x, 305 + y + h, 90, 60);
    ellipse(330 + x, 305 + y + h, 90, 60);
  
    noStroke();
    fill(40);
    rect(40 + x, 285 + y + h, 50, 40, 10);
    rect(310 + x, 285 + y + h, 50, 40, 10);

    stroke(0);
    strokeWeight(1);
    fill(235);
    rect(80 + x, 275 + y + h, 240, 40, 20, 20, 0, 0);
    fill(235);
    rect(80 + x, 315 + y + h, 240, 20, 0, 0, 10, 10);
    fill(205);
    rect(160 + x, 275 + y + h , 80, 30, 3, 3, 10, 10);
    noStroke();
    fill(0, 20);
    rect(95 + x, 275 + y + h, 210, 40 - (h / 3 + 20), 10);
  
    //Arms
      //Left Clamp
    stroke(0);
    strokeWeight(1);
    fill(105);
    for(i = 0; i < 7; i++){
      beginShape();
      vertex(45 + x + i, 115 + y + h + i);
      vertex(100 + x + i, 115 + y + h + i);
      vertex(100 + x + i, 125 + y + h + i);
      vertex(60 + x + i, 170 + y + h + i);
      vertex(45 + x + i, 170 + y + h + i);
      vertex(45 + x + i, 115 + y + h + i);
      endShape();
    }
    fill(40);
    for(i = 0; i < 20; i++){
      rect(50 + x + i, 120 + y + h, 20, 130, 5, 10, 10, 10);
    }
    stroke(0);
    strokeWeight(1);
    fill(60);
    rect(50 + x, 120 + y + h, 20, 130, 5, 10, 10, 10);

    
    stroke(0);
    strokeWeight(1);
    fill(155);
    beginShape();
    vertex(45 + x, 115 + y + h);
    vertex(100 + x, 115 + y + h);
    vertex(60 + x, 170 + y + h);
    vertex(45 + x, 170 + y + h);
    vertex(45 + x, 115 + y + h);
    endShape();
   
    //Left Arm
    fill(75);
    for(i = 0; i < 5; i++){
      arc(60 + x, 205 + y + h + i, 20, 20, PI, 0);
      beginShape();
      vertex(70 + x, 205 + y + h + i);
      vertex(65 + x, 245 + y + h + i);  
      vertex(80 + x, 280 + y + h + i);
      vertex(60 + x, 280 + y + h + i);
      vertex(45 + x, 245 + y + h + i);
      vertex(50 + x, 205 + y + h + i);
      endShape();
    
      beginShape();
      vertex(60 + x, 278 + y + h + i);
      vertex(33 + x, 300 + y + h + i);
      vertex(45 + x, 323 + y + h + i);
      vertex(77 + x, 320 + y + h + i);
      vertex(80 + x, 278 + y + h + i);
      endShape();
    }
    fill(155);
    stroke(1);
    strokeWeight(1);
    arc(60 + x, 205 + y + h, 20, 20, PI, 0);
    beginShape();
    vertex(70 + x, 205 + y + h);
    vertex(65 + x, 245 + y + h);  
    vertex(80 + x, 280 + y + h);
    vertex(60 + x, 280 + y + h);
    vertex(45 + x, 245 + y + h);
    vertex(50 + x, 205 + y + h);
    endShape();
    
    beginShape();
    vertex(60 + x, 278 + y + h);
    vertex(33 + x, 300 + y + h);
    vertex(45 + x, 323 + y + h );
    vertex(77 + x, 320 + y + h);
    vertex(80 + x, 278 + y + h);
    endShape();

    //Right Clamp
    fill(105);
    for(i = 0; i < 7; i++){
      beginShape();
      vertex(355 + x - i, 115 + y + h + i);
      vertex(300 + x - i, 115 + y + h + i);
      vertex(340 + x - i, 170 + y + h + i);
      vertex(355 + x - i, 170 + y + h + i);
      vertex(355 + x - i, 115 + y + h + i);
      endShape();
    }
    fill(40);
    for(i = 0; i < 20; i++){
      rect(330 + x - i, 120 + y + h, 20, 130, 10, 5, 10, 10);
    }
    fill(60);
    rect(330 + x, 120 + y + h, 20, 130, 10, 5, 10, 10);
  
    fill(155);
    beginShape();
    vertex(355 + x, 115 + y + h);
    vertex(300 + x, 115 + y + h);
    vertex(340 + x, 170 + y + h);
    vertex(355 + x, 170 + y + h);
    vertex(355 + x, 115 + y + h);
    endShape();
  
      //Right Arm
    fill(75);
    for(i = 0; i < 5; i++){
      arc(340 + x, 205 + y + h + i, 20, 20, PI, 0);
      beginShape();
      vertex(330 + x, 205 + y + h + i);
      vertex(335 + x, 245 + y + h + i);  
      vertex(335 + x, 245 + y + h + i);
      vertex(320 + x, 280 + y + h + i);
      vertex(340 + x, 280 + y + h + i);
      vertex(355 + x, 245 + y + h + i);
      vertex(350 + x, 205 + y + h + i);
      endShape();
    
      beginShape();
      vertex(340 + x, 278 + y + h + i);
      vertex(367 + x, 300 + y + h + i);
      vertex(355 + x, 323 + y + h + i);
      vertex(323 + x, 320 + y + h + i);
      vertex(320 + x, 278 + y + h + i);
      endShape();
    }
    fill(155);
    stroke(1);
    strokeWeight(1);
    arc(340 + x, 205 + y + h, 20, 20, PI, 0);
    beginShape();
    vertex(330 + x, 205 + y + h);
    vertex(335 + x, 245 + y + h);  
    vertex(335 + x, 245 + y + h);
    vertex(320 + x, 280 + y + h);
    vertex(340 + x, 280 + y + h);
    vertex(355 + x, 245 + y + h);
    vertex(350 + x, 205 + y + h);
    endShape();
  
    beginShape();
    vertex(340 + x, 278 + y + h);
    vertex(367 + x, 300 + y + h);
    vertex(355 + x, 323 + y + h);
    vertex(323 + x, 320 + y + h);
    vertex(320 + x, 278 + y + h);
    endShape();
    
    //Bolts on Arms
    fill(75);
    ellipse(59 + x, 155 + y, 12, 12);
    ellipse(341 + x, 155 + y, 12, 12);
  }
  
}
function drawRobHead(x, y, h){
  //Face
  stroke(0);
  strokeWeight(1);
  //Light
  fill(robLight,0,0)
  ellipse(200 + x, 100 + y, 40, 35);
  
  fill(225);
  rect(175 + x, 98 + y, 50, 5);
  rect(95 + x, 120 + y, 10, 60, 10);
  rect(295 + x, 120 + y, 10, 60, 10);

  rect(100 + x, 100 + y, 200, 100, 10);
  
  fill(40);
  rect(107 + x, 107 + y, 186, 86, 10);
  
  strokeWeight(2);
  fill(30);
  rect(115 + x, 115 + y, 170, 70, 20);
  
  fill(0);
  stroke(0);
  strokeWeight(5);
  line(150 + x, 135 + y, 250 + x, 135 + y);
  line(150 + x, 150 + y, 250 + x, 150 + y);
  line(150 + x, 165 + y, 250 + x, 165 + y);
  
  //Eyes
  fill(0);
  stroke(0);
  strokeWeight(1);
  ellipse(150 + x, 150 + y, 60, 60);
  ellipse(250 + x, 150 + y, 60, 60);
  
  //Lighting for Eyes
  fill(255, 175);
  noStroke();
  ellipse(160 + x, 135 + y, 10, 10);
  ellipse(260 + x, 135 + y, 10, 10);
  
  //Eye Reflection
  for(var i = 0; i <= 5; i++){
    fill(125 - i * 25, 150);
    arc(150 + x, 150 + y, 60 - i * 5, 60 - i * 5, 70, 650);
    fill(0);
    arc(150 + x, 150 + y, 55 - i * 5, 55 - i * 5, 70, 650);
    fill(125 - i * 25, 150);
    arc(250 + x, 150 + y, 60 - i * 5, 60 - i * 5, 70, 650);
    fill(0);
    arc(250 + x, 150 + y, 55 - i * 5, 55 - i * 5, 70, 650);
  }
}
function drawRobHead2(x, y, h){
  //Face
  stroke(0);
  strokeWeight(1);
  //light
  fill(robLight2,0,0)
  ellipse(200 + x, 100 + y, 40, 35);
  
  fill(225);
  rect(175 + x, 98 + y, 50, 5);
  rect(95 + x, 120 + y, 10, 60, 10);
  rect(295 + x, 120 + y, 10, 60, 10);

  rect(100 + x, 100 + y, 200, 100, 10);
  
  fill(40);
  rect(107 + x, 107 + y, 186, 86, 10);
  
  strokeWeight(2);
  fill(30);
  rect(115 + x, 115 + y, 170, 70, 20);
  
  fill(0);
  stroke(0);
  strokeWeight(5);
  line(150 + x, 135 + y, 250 + x, 135 + y);
  line(150 + x, 150 + y, 250 + x, 150 + y);
  line(150 + x, 165 + y, 250 + x, 165 + y);
  
  //Eyes
  fill(0);
  stroke(0);
  strokeWeight(1);
  ellipse(150 + x, 150 + y, 60, 60);
  ellipse(250 + x, 150 + y, 60, 60);
  
  //Lighting for Eyes
  fill(255, 175);
  noStroke();
  ellipse(160 + x, 135 + y, 10, 10);
  ellipse(260 + x, 135 + y, 10, 10);
  
  //Eye Reflection
  for(var i = 0; i <= 5; i++){
    fill(125 - i * 25, 150);
    arc(150 + x, 150 + y, 60 - i * 5, 60 - i * 5, 70, 650);
    fill(0);
    arc(150 + x, 150 + y, 55 - i * 5, 55 - i * 5, 70, 650);
    fill(125 - i * 25, 150);
    arc(250 + x, 150 + y, 60 - i * 5, 60 - i * 5, 70, 650);
    fill(0);
    arc(250 + x, 150 + y, 55 - i * 5, 55 - i * 5, 70, 650);
  }
}
function keyPressed(){
  //R.O.B. light changing on press
  if(key == "j" && robLight == 0 && screen == "keyLesson1"){
    robLight = 255;
  }
  else if(key != "k"){
    robLight = 0;  
  }
  
  if(keyIsDown(BACKSPACE) && extend == 0){
    count = 0;
    down = false;
    capture = false;
  }
}
function keyReleased(){
  //R.O.B. light change on release 
  if(key == "k" && robLight2 == 0 && screen == "keyLesson1"){
    robLight2 = 255;
  }
  else if(key != "j"){
    robLight2 = 0;  
  }
}
function mouseClicked(){
  //Start Button on R.O.B.
  if(mouseX > 200 && mouseY > 290 && mouseX < 400 && mouseY < 340 && screen == "intro"){
    screen = "title";
    start = true;
  }
  
  //How to use R.O.B. button
  if(mouseX >= 35 && mouseX <= 155 && mouseY >= 45 && mouseY <= 105 && screen == "keyLesson4"){
    exemplar = false;
    screen = "howRobWorks";
    pressed = false;
    jokeTimer = 0;
    jokeLine = 0;
  }
  else if(mouseX >= 35 && mouseX <= 155 && mouseY >= 45 && mouseY <= 105 && screen == "howRobWorks"){
    exemplar = true;
    screen = "keyLesson4";
  }
  
  //Back Buttons for Lessons
  else if(mouseX >= 35 && mouseX <= 155 && mouseY >= 45 && mouseY <= 105 && screen == "keyLesson1"){
    robAniTimer = 0;
    rise = 0;
    tarXY = [0, 0];
    //curXY = [0, 0];
    frameX = 0;
    frameY = 0;
    robLeft = false;
    robRight = false;
    robDown = false;
    robUp = false;
    screen = "title";
    robX = 100;
    robY = -25;
    i = 0;
    pressed = false;
    jokeTimer = 0;
    jokeLine = 0;
    }
  else if(mouseX >= 440 && mouseX <= 520 && mouseY >= 65 && mouseY <= 125 && screen == "keyLesson2"){
    robAniTimer = 0;
    rise = 0;
    tarXY = [0, 0];
    //curXY = [0, 0];
    frameX = 0;
    frameY = 0;
    robLeft = false;
    robRight = false;
    robDown = false;
    robUp = false;
    robX = 100;
    robY = -25;
    screen = "title";
    i = 0;
    pressed = false;
    jokeTimer = 0;
    jokeLine = 0;
  }
  else if(mouseX >= 440 && mouseX <= 560 && mouseY >= 65 && mouseY <= 125 && screen == "keyLesson3"){
    robAniTimer = 0;
    rise = 0;
    tarXY = [0, 0];
    //curXY = [0, 0];
    frameX = 0;
    frameY = 0;
    robLeft = false;
    robRight = false;
    robDown = false;
    robUp = false;
    robX = 100;
    robY = -25;
    screen = "title";
    i = 0;
    pressed = false;
    pressed = false;
    jokeTimer = 0;
    jokeLine = 0;
    }
  else if(mouseX >= 440 && mouseX <= 560 && mouseY >= 45 && mouseY <= 105 && screen == "keyLesson4"){
    robAniTimer = 0;
    rise = 0;
    tarXY = [0, 0];
    //curXY = [0, 0];
    frameX = 0;
    frameY = 0;
    robLeft = false;
    robRight = false;
    robDown = false;
    robUp = false;
    robX = 100;
    robY = -25;
    screen = "title"; 
    i = 0;
    jokeTimer = 0;
    jokeLine = 0;
    }
  
  
  //Buttons for Switching between 'How it Works' && Lessons
  else if(mouseX >= 440 && mouseX <= 560 && mouseY >= 140 && mouseY <= 190 && screen == "keyLesson2"){
    exemplar = false;
    screen = "works2";
  }
  else if(mouseX >= 440 && mouseX <= 560 && mouseY >= 140 && mouseY <= 190 && screen == "works2"){
    exemplar = true;
    screen = "keyLesson2"
    
  }
  else if(mouseX >= 35 && mouseX <= 155 && mouseY >= 120 && mouseY <= 170 && screen == "keyLesson1"){
    exemplar = false;
    screen = "works1"
    
  }
  else if(mouseX >= 440 && mouseX <= 560 && mouseY >= 140 && mouseY <= 190 && screen == "works1"){
    exemplar = true;
    screen = "keyLesson1"
  }
}